#include<stdio.h>
#include<string.h>

int main(){
	int tc, t;
	char srt[105][55], ori[105][55], sent[105];
	
	FILE *fR=fopen("testdata.in", "r");
	fscanf(fR, "%d\n", &t);
	for(int i=0;i<t;i++){
		fscanf(fR,"%[^#]#%[^\n]\n", srt[i], ori[i]);
	}
	
	fscanf(fR, "%d\n", &tc);
	
	for(int i=1;i<=tc;i++){
		fscanf(fR,"%[^\n]\n", sent);
		int len=strlen(sent);
		int j=0;
		
		printf("Case #%d:\n", i);
		
		while(j<=len){
			char cek[55]={'\0'};
			int k=0;
			while(sent[j]!=' ' && sent[j]!='\n' && sent[j]!='\0'){
				cek[k]=sent[j];
				k++;
				j++;
			}
			for(int m=0;m<=t;m++){
				if(strcmp(cek, srt[m])==0){
					printf("%s", ori[m]); break;
				}
				else if(m==t){
					printf("%s", cek);
				}
			}
			(j!=len)?printf(" "):printf("\n");
			j++;
		}
	}
	fclose(fR);
	return 0;
}
