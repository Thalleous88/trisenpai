#include<stdio.h>
#include<string.h>

struct data{
    char nama[1001];
    long long int score;
};

void sort(struct data siswa[], int count) {
    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - 1 - i; j++) {
            if (siswa[j].score < siswa[j + 1].score || 
                (siswa[j].score == siswa[j + 1].score && strcmp(siswa[j].nama, siswa[j + 1].nama) > 0)) {

                char tempo[11];
                strcpy(tempo, siswa[j].nama);
                strcpy(siswa[j].nama, siswa[j + 1].nama);
                strcpy(siswa[j + 1].nama, tempo);

                int temp;
                temp = siswa[j].score;
                siswa[j].score = siswa[j + 1].score;
                siswa[j + 1].score = temp;
            }
        }
    }
}

int cari(struct data siswa[], int stud, char ask[]) {
    for (int i = 0; i < stud; i++) {
        if (strcmp(siswa[i].nama, ask) == 0) {
            return i + 1;
        }
    }
    return -1;
}

int main() {
    int t;
    scanf("%d", &t);
	getchar();
	
    for (int i = 0; i < t; i++) {
        long long int stud;
        scanf(" %lld", &stud);getchar();

        struct data siswa[stud];

        for (int j = 0; j < stud; j++) {
            scanf(" %[^#]#%lld", siswa[j].nama, &siswa[j].score);
            getchar();
        }   
		
	//	getchar();
		
        char ask[1001];
        scanf(" %s", ask);

        sort(siswa, stud);

        int hasil = cari(siswa, stud, ask);

        printf("Case #%d: %d\n", i + 1, hasil);
    }

    return 0;
}
/*
#include<stdio.h>
#include<string.h>

struct dar{
	long long int nilai;
	char nama[1010];
}data[1010], temp;

int cekRank(char src[1010],  int n){
	for(int i=0;i<n;i++){
		if(strcmp(data[i].nama, src)==0)return i+1;
	}
	return -1;
}

int main(){
	int t, n;
	char src[1010];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			scanf("%[^#]#%lld\n", data[j].nama, &data[j].nilai); //getchar();
		}
		for(int j=0;j<n;j++){
			for(int k=0;k<n-j-1;k++){
				if(data[k].nilai<data[k+1].nilai){
					temp=data[k];
					data[k]=data[k+1];
					data[k+1]=temp;
				}
				else if(data[k].nilai==data[k+1].nilai){
					int l=0;
					while(data[k].nama[l]==data[k+1].nama[l]){
						l++;
					}
					if(data[k].nama[l]<data[k+1].nama[l]){
						temp=data[k];
						data[k]=data[k+1];
						data[k+1]=temp;
					}
				} 
			}
		}
		scanf("%[^\n]", src); getchar();
		printf("Case #%d: %d\n", i, cekRank(src, n));
	}
	
	return 0;
}
*/
