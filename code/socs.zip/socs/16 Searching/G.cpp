#include<stdio.h>

int main(){
	int t, n, k, a;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &n, &k);
		int counter=0;
		for(int j=0;j<n;j++){
			scanf("%d", &a);
			if(a>=k)counter++;
		}
		printf("Case #%d: %d\n", i, counter);
	}
	
	return 0;
}
