#include<stdio.h>

int main(){
	int a, n;
	scanf("%d", &n);
	int counter=0;
	for(int i=0;i<n;i++){
		scanf("%d", &a);
		if(a==1)counter++;
	}
	counter==0?printf("easy\n"):printf("not easy\n");
	return 0;
}
