#include<stdio.h>
#include<string.h>

int check(char num[105][15], char s[15], int n){
	for(int j=0;j<n;j++){
		if(strcmp(num[j], s)==0)return j+1;
	}
	return 0;
}

int main(){
	int n, t;
	char name[105][25], num[105][15], s[15];
	FILE *fR;
	fR=fopen("testdata.in", "r");
	fscanf(fR, "%d", &n);
	for(int i=0;i<n;i++){
		fscanf(fR,"%s %[^\n]\n", num[i], name[i]);
	}
	fscanf(fR, "%d", &t);
	for(int i=1;i<=t;i++){
		fscanf(fR,"%s\n", s);
		int l=check(num, s, n);
		if(l){
			printf("Case #%d: %s\n", i, name[l-1]);
		}else{
			printf("Case #%d: N/A\n", i);
		}
	}
	fclose(fR);
	return 0;
}
