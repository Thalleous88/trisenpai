#include<stdio.h>

int cekSame(int a, int num[101], int m){
	for(int i=0;i<m;i++){
		if(a==num[i])return 0;
	}
	return 1;
}

int main(){
	int max=-1;
	int n, m, num1[101], num2[101];
	scanf("%d %d", &n, &m);
	for(int i=0;i<n;i++){
		scanf("%d", &num1[i]);
	}
	for(int i=0;i<m;i++){
		scanf("%d", &num2[i]);
	}
	for(int i=0;i<n;i++){
		if(cekSame(num1[i], num2, m) &&  num1[i]>max){
			max=num1[i];
		}
	}
	printf("Maximum number is %d\n", max);
	
	return 0;
}
