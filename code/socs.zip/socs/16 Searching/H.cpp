#include<stdio.h>

int main(){
	int n;
	long long int x[105], y;
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%lld", &x[i]);
	}
	scanf("%lld", &y);
	for(int i=0;i<n;i++){
		for(int k=0;k<n-i-1;k++){
			if(x[k]>x[k+1]){
				long long int temp=x[k];
				x[k]=x[k+1];
				x[k+1]=temp;
			}
		}
	}
	int j=0;
	while(j<n && y-x[j]>=0){
		y=y-x[j];
		j++;
	}
	printf("%d\n", j);
	return 0;
}
