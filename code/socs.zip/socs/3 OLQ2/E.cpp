#include<stdio.h>
int main()
{
	double n;
	scanf("%lf",&n);
	printf("%lf\n",floor(n));
	printf("%lf\n",ceil(n));	
	return 0;
}
