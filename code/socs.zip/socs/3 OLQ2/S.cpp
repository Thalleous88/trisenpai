#include<stdio.h>
#include<math.h>
int main()
{
	double l;
	double b;
	double h;
	double x, y, ttl;
	scanf("%lf %lf %lf", &l, &b, &h);
	x=b*h*0.5;
	y=l*b;
	//w=sqrt(h*h+0.5*b*b*0.5);
	//z=w*l;
	ttl=x*2+y*3;
	printf("%.3lf\n",ttl);
	return 0;
}
