#include<stdio.h>
int main(){
	int tc=5;
	char CourseCode[100];
	int time1, time2, time3, time4;
	while (tc--){
		scanf("%s %d:%d-%d:%d",CourseCode, &time1, &time2, &time3, &time4); getchar();
		printf("%s %02d:%02d-%02d:%02d\n", CourseCode, time1-1, time2, time3-1, time4);
		
	}
	return 0;
}
