#include<stdio.h>
int main ()
{
	int a, b;
	int c=3;
	while (c--){
		scanf("%d + %d =",&a,&b);
		printf("%d\n", a+b);
	}
//	scanf("%d + %d =",&a,&b);getchar();
//	scanf("%d + %d =",&d,&e);getchar();
//	scanf("%d + %d =",&g,&h);getchar();
//	c=a+b;
//	f=d+e;
//	i=g+h;	
//	printf("%d%\n%d\n%d\n", c, f, i);
	return 0;
}

