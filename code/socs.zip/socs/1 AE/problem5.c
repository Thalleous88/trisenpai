#include <stdio.h>
int main(){
    int tc;
    int a,b,c;
    scanf("%d",&tc);
    for(int i=1;(i<tc+1)&&scanf("%d%d%d",&a,&b,&c);i++){
        printf("Case #%d: ",i);
        puts(((b+c)>=a)?"yes":"no");
    }
    return 0;
}

