#include <stdio.h>

int main (){
	
	int A;
	scanf ("%d", &A); getchar();
	if (A%2==0){
		printf ("EVEN\n");
	}
	else {
		printf("ODD\n");
	}
	return 0;
}
