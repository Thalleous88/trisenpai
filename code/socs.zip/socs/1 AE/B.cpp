#include <stdio.h>

int main (){
	
	int n, m;
	scanf ("%d %d", &n, &m); getchar();
	
/*	for (int i=1; i<=m; i++){	
		printf ("%d\n", n);
		n=n+1;
	}
	*/
 	while (m--){
 		printf ("%d\n",n);
 		n++;
	 }

	
	return 0;
}
