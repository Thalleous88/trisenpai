#include<stdio.h>
int main()
{
	int k, n, m, t, i;
	// t testcase
	// k butuh
	// n punya
	// m ada di toko
	scanf("%d", &t);
	
	for(i=0;i<t;i++);
	scanf("%d %d %d", &k, &n, &m);
	if(n+m<k){
		printf("Case #%d: no\n", i+1);
	}
	else{
		printf("Case #%d: yes\n", i+1);
	}
	return 0;
}
