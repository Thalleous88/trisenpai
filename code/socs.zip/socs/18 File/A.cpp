#include<stdio.h>
#include<string.h>

struct data{
	char name[50];
	char tree[50];
}list[150];

int srchList(char src[50], int n){
	for(int i=0;i<n;i++){
		if(strcmp(src, list[i].name)==0){
			return i;
		}
	}
	return -1;
	
}

int main(){
	int n, t;
	char src[50];
	FILE *fr=fopen("testdata.in", "r");
	fscanf(fr, "%d\n", &n);
	for(int i=0;i<n;i++){
		fscanf(fr, "%[^#]#%[^\n]\n", list[i].name, list[i].tree);
	}
	fscanf(fr, "%d\n", &t);
	for(int i=1;i<=t;i++){
		fscanf(fr, "%[^\n]\n", src);
		int j=srchList(src, n);
		printf("Case #%d: ", i);
		if(j!=-1){
			printf("%s\n", list[j].tree);
		}else{
			printf("N/A\n");
		}
	}
	return 0;
}
