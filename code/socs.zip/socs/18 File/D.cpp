#include<stdio.h>
#include<string.h>

int main(){
	int t, n;
	char str[150];
	FILE *fr=fopen("testdata.in", "r");
	fscanf(fr, "%d\n", &t);
	for(int j=1;j<=t;j++){
		char from[50], to[50];
		fscanf(fr, "%[^\n]\n", str);
		fscanf(fr, "%d\n", &n);
		for(int i=0;i<n;i++){
			fscanf(fr, " %c", &from[i]);
			fscanf(fr, " %c", &to[i]);
		}
		for(int i=0;i<strlen(str);i++){
			for(int k=0;k<n;k++){
				if(str[i]==from[k]){
					str[i]=to[k];
					break;
				}
			}
		}
		for(int i='A';i<='Z';i++){
			int count=0;
			for(int k=0;k<strlen(str);k++){
				if(str[k]==i){
					count++;
				}
			}
			if(count>0){
				printf("%c %d\n", i, count);
			}
		}
	}
	fclose(fr);
	return 0;
}
