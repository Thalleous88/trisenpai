#include<stdio.h>

int countKeliling(int n, int x[150]){
	int kel=0;
	for(int j=0;j<n;j++){
		kel=kel+x[j]*4-(x[j]-1)*2;
		if(j!=0){
			if(x[j]>x[j-1]){
				kel=kel-x[j-1];
			}
			else if(x[j]<=x[j-1]){
				kel=kel-x[j];
			}
		}
		if(j!=n-1){
			if(x[j]>x[j+1]){
				kel=kel-x[j+1];
			}
			else if(x[j]<=x[j+1]){
				kel=kel-x[j];
			}
		}
	}
	return kel;
}

int main(){
	int t, n, x[150];
	int sisi=2;
	int luas=sisi*sisi;
	FILE *fpn=fopen("testdata.in", "r");
	fscanf(fpn, "%d", &t);
	for(int i=1;i<=t;i++){
		fscanf(fpn, "%d", &n);
		int total=0;
		for(int j=0;j<n;j++){
			fscanf(fpn, "%d", &x[j]);
			total=total+x[j];
		}
		printf("Case #%d: %d %d\n", i, 2*countKeliling(n, x),total*luas);
	}
	return 0;
}
