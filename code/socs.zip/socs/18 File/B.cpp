#include<stdio.h>
#include<string.h>

int main(){
	int t, n;
	char str[1005];
	FILE *fr=fopen("testdata.in", "r");
	fscanf(fr, "%d\n", &t);	
	for(int i=1;i<=t;i++){
		fscanf(fr, "%d\n", &n);	
		fscanf(fr, "%[^\n]\n", str);	
		int len=strlen(str);
		for(int j=0;j<len;j++){
			if(str[j]=='0'){
				str[j]='O';
			}else if(str[j]=='1'){
				str[j]='I';
			}else if(str[j]=='3'){
				str[j]='E';
			}else if(str[j]=='4'){
				str[j]='A';
			}else if(str[j]=='5'){
				str[j]='S';
			}else if(str[j]=='6'){
				str[j]='G';
			}else if(str[j]=='7'){
				str[j]='T';
			}else if(str[j]=='8'){
				str[j]='B';
			}
		}
		printf("Case #%d: ", i);
		for(int j=0;j<len;j++){
			for(int k=0;k<n;k++){
				if(str[j]=='A'){
					str[j]='Z';
				}else if(str[j]==' '){
					break;
				}else{
					str[j]-=1;
				}
			}
			printf("%c", str[j]);
		}printf("\n");
	}
	
	return 0;
}
