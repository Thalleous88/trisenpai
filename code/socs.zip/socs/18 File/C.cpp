#include<stdio.h>

int main(){
	int a, b;
	FILE *f=fopen("testdata.in", "r");
	fscanf(f, "%d %d", &a, &b);
	fclose(f);
	printf("%d\n", a+b);
	
	return 0;
}
