#include<stdio.h>
int main(){
	long long int n, m, t;
	scanf("%lld", &t);
	for(int i=1 ; i<=t ; i++){
		scanf("%lld %lld", &n, &m); getchar();
		if((n*m)%2!=0){
			printf("Case #%d: Need more frogs!\n", i);
		}
		else if ((n*m)%2==0){
			printf("Case #%d: Party time!\n", i);
		}
	}
	return 0;
}

