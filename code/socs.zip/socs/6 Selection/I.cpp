#include<stdio.h>
int main(){
	int t;
	long long int a, b, c;
	scanf("%d", &t); getchar();
	for (int i=1 ; i<=t ; i++){
		scanf("%lld %lld %lld", &a, &b, &c);
		if(a*b/100>c){
			printf("Case #%d: %lld\n", i, c);
		}
		else{
			printf("Case #%d: %lld\n", i, a*b/100);
		}
	}
	return 0;
}
