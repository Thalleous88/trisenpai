#include<stdio.h>
int main(){
	int t, k, n, m, i;
	scanf("%d", &t); getchar();
	for(int i=1 ; i<=t ; i++){
		scanf("%d %d %d", &k, &n, &m); getchar();
		if(k>n+m){
			printf("Case #%d: no\n", i);	
		}
		else{
			printf("Case #%d: yes\n", i);
		}

	}
}
