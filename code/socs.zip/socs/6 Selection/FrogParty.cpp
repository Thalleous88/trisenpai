#include<stdio.h>
int main(){
	int t;
	long long int n, m;
	scanf("%d", &t);
	for(int i=1 ; i<=t ; i++){
		scanf("%lld %lld", &n, &m);
		if((n*m)%2==0){
			printf("Case #%d: Party time!\n", i);
		}else if((n*m)%2!=0){
			printf("Case #%d: Need more frogs\n", i);
		}
	}
	return 0;
}
