#include<stdio.h>

int main(){
	int usia;
	scanf("%d", &usia);
	
	printf("Selamat ulang tahun yang ke %d yaaa!\n",usia);
	return 0;
}
