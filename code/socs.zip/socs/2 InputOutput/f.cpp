#include<stdio.h>

int main (){
	char kata [100];
	int angka;
	
	scanf ("%s", &kata); getchar ();
	scanf ("%d", &angka);
	
	
	printf ("%s\n", kata);
	printf ("%d\n", angka);
	
	return 0;
}
