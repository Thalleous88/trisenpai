#include<stdio.h>
int main(){
	char name[101];
	scanf("%s", &name);
	
	printf("%s-san\n",name);
	return 0;
}
