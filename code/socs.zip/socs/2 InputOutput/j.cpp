#include<stdio.h>

int main(){
	int num;
	scanf("%d", &num);
	
	printf("%x\n",num);
	return 0;
}
