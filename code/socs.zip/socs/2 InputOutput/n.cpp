#include<stdio.h>
int main()
{
	char nama1[101],usia1[101]; //string ini
	double tinggi1;
	char nama2[101],usia2[101];//string
	double tinggi2;
		
	scanf("%s",nama1); getchar(); //klo ada array pke s jgn c
	scanf("%lf",&tinggi1); getchar(); //jgn lupa &nya
	scanf("%s",usia1); getchar();//s bkn c
	scanf("%s",nama2); getchar();//s lh bkn c
	scanf("%lf",&tinggi2); getchar(); // jgn lupa &
	scanf("%s",usia2); getchar();//s bkn c

	printf("Name 1: %s\n",nama1);
	printf("Height 1: %.2lf\n",tinggi1);
	printf("Age 1: %s\n",usia1);
	printf("Name 2: %s\n",nama2);
	printf("Height 2: %.2lf\n",tinggi2); // habis koma jgn pke spasi
	printf("Age 2: %s\n",usia2);	
	
	return 0;
}
