#include<stdio.h>
int main()
{
	char one[21],two[21],tri[21];
	scanf("%s %s %s", one, two, tri);
	printf("%s %s %s\n", tri, two, one);
	return 0;
}
