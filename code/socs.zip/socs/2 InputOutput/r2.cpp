#include<stdio.h>
int main()
{
	char stuID[15], nama[100], kelas;
	int stuNum;
	
	scanf("%s",stuID);getchar();
	scanf("%[^\n]",nama);getchar();
	scanf("%c %d",&kelas,&stuNum);getchar();
	
	printf("Id    : %s\n",stuID);
	printf("Name  : %s\n",nama);
	printf("Class : %c\n",kelas);	
	printf("Num   : %d\n",stuNum);
	return 0;
}
