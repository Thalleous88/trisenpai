#include<stdio.h>

int main (){
	char nama[100];
	
	scanf ("%s", nama); getchar ();
	
	printf ("Hello %s!\n", nama);
	
	return 0;
}
