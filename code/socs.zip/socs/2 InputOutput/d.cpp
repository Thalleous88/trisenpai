#include <stdio.h>

int main (){
	
	printf ("Hello Maba!\n");
	
	return 0;
}
