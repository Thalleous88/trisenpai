#include<stdio.h>
int main()
{
	char word[101];
	scanf("%s",word);
	printf("Halo %s\n",word); //jgn lupa \n
	return 0;
}
