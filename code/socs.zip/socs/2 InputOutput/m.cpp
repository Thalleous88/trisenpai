#include<stdio.h>

int main(){
	int num;
	scanf("%d", &num);
	
	printf("%o\n",num);
	return 0;
}
