#include <stdio.h>

int main (){
	
	printf ("Binus FTW!\n");
	
	return 0;
}
