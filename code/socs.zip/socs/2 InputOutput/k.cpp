#include<stdio.h>

int main (){
	char nama[101]; //untuk array ditambahin 1, jgn sama persis
	char NIS[9];
	int usia;
	
	scanf ("%[^\n]", nama); getchar ();
	scanf ("%s", NIS); scanf ("%d", &usia); getchar ();
	
	printf ("Name: %s\n", nama);
	printf ("NIS: %s\n", NIS);
	printf ("Age: %d\n", usia);	
	return 0;
}

