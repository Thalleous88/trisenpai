#include<stdio.h>

int cekNum(int num[1010], int f, int n){
	for(int j=0;j<n;j++){
		if(num[j]==f) return j+1;
	}
	return 0;
}

int main(){
	int k, n, num[1010], f, j;
	scanf("%d", &k);
	for(int i=0;i<k;i++){
		scanf("%d", &n);
		j=0;
		while(j<n){
			scanf("%d", &num[j]);	
			j++;		
		}
		scanf("%d", &f);
		int l=cekNum(num, f, n);
		if(l){
			if(l!=j){
				printf("CASE #%d: %d %d\n", i+1, num[l-1], num[l]);				
			}
			else{
				printf("CASE #%d: %d %d\n", i+1, num[l-2], num[l-1]);	
			}	
		}
		else{
			printf("CASE #%d: -1 -1\n", i+1);
		}
	}
	return 0;
}

