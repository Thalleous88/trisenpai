#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct filee{
	char num[12];
	char name[25];
} data[1010], temp;

int main(){
	int n;
	FILE *f;
	f=fopen("testdata.in", "r");
	fscanf(f, "%d", &n);
	for(int i=0;i<n;i++){
		fscanf(f,"%s %s\n", data[i].num, data[i].name);
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n-i-1;j++){
			int k=0;
			while(data[j].num[k]==data[j+1].num[k]){
				k++;
			}
			if(data[j].num[k]>data[j+1].num[k]){
				struct filee temp=data[j];
				data[j]=data[j+1];
				data[j+1]=temp;
			}
		}
	}
	for(int i=0;i<n;i++){
		printf("%s %s\n", data[i].num, data[i].name);
	}
	fclose(f);		
	return 0;
}
/*
#include<stdio.h>
#include<string.h>

struct filee{
	long long int num;
	char name[25];
} data[1010];

int main(){
	int n;
	FILE *f;
	f=fopen("testdata.in", "r");
	fscanf(f, "%d", &n);
	for(int i=0;i<n;i++){
		fscanf(f,"%lld %s", &data[i].num, data[i].name);
	}
	fclose(f);
	for(int i=0;i<n;i++){
		for(int j=0;j<n-i-1;j++){
			if(data[j].num>data[j+1].num){
				long long int temp1=data[j].num;
				data[j].num=data[j+1].num;
				data[j+1].num=temp1;
				char temp2[25];
				strcpy(temp2, data[j].name);
				strcpy(data[j].name, data[j+1].name);
				strcpy(data[j+1].name, temp2);
			}
		}
	}
	for(int i=0;i<n;i++){
		printf("%lld %s\n", data[i].num, data[i].name);
	}	
	return 0;
}
*/
