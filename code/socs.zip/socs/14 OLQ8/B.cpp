#include<stdio.h>
int main(){
	int n;
	char arr[150][150];
	scanf("%d", &n); getchar();
	for(int i=0;i<n;i++){
		scanf("%s", arr[i]);
		getchar();
	}
	for(int i=n-1;i>=0;i--){
		for(int j=n-1;j>=0;j--){
			printf("%c", arr[i][j]);
		}
		printf("\n");
	}	
	return 0;
}
