#include<stdio.h>
int main(){
	int t, n, m, x[150], arr1[10005], arr2[10005];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &n, &m); //ruangan, jumlah pattern
		for(int j=0;j<m;j++){
			scanf("%d", &x[j]);
		}
		for(int j=0;j<n;j++){
			arr1[j]=j+1; //nomor ruangan
			arr2[j]=1; //set to open
		}
		int counter=n;
		printf("Case #%d:", i);
		for(int j=0;j<n;j++){
			for(int k=0;k<m;k++){
				if(arr1[j]%x[k]==0){
					if(arr2[j]==1){
						arr2[j]=0;
						counter--;
					}else{
						arr2[j]=1;
						counter++;
					}
				}
			}
			if(arr2[j]==1) printf(" %d", arr1[j]);
		}
		if(counter==0)printf(" No room left!");
		printf("\n");
	}
	return 0;
}
