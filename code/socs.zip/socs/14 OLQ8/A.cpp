#include<stdio.h>
int main(){
	int arr[150][150], n;
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &arr[j][i]);
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf("%d", arr[i][j]);
			if(j!=n-1)printf(" ");
		}
		printf("\n");
	}	
	return 0;
}
