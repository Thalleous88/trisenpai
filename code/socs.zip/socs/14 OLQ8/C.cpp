#include<stdio.h>
int main(){
	int x, y, t, a, b, c, arr[150][150];
	scanf("%d %d", &x, &y);
	for(int i=1;i<=x;i++){
		for(int j=1;j<=y;j++){
			scanf("%d", &arr[j][i]);
		}
	}
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		scanf("%d %d %d", &a, &b, &c);
		arr[b][a]=c;
	}
	for(int i=1;i<=x;i++){
		for(int j=1;j<=y;j++){
			printf("%d", arr[j][i]);
			if(j!=y)printf(" ");
		}
		printf("\n");	
	}
	return 0;
}
