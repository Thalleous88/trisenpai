#include<stdio.h>
#include<math.h>
int main()
{
	unsigned long long int a, b;
	scanf("%llu", &a);
	b=pow(2,a);
	printf("%llu\n", b-1);
	return 0;
}
