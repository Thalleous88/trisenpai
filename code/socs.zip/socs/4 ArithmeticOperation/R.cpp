#include<stdio.h>
int main ()
{
	long int a, b, c, d, e, f, g, h, i, j, k, l, m, n, o;
	scanf("(%ld+%ld)x(%ld-%ld)", &a, &b, &c, &d); getchar();
	scanf("(%ld+%ld)x(%ld-%ld)", &e, &f, &g, &h); getchar();
	scanf("(%ld+%ld)x(%ld-%ld)", &i, &j, &k, &l); getchar();
	m=(a+b)*(c-d);
	n=(e+f)*(g-h);
	o=(i+j)*(k-l);
	printf("%ld %ld %ld\n", m, n, o);
	return 0;
}
