#include<stdio.h>
int main ()
{
	double  a, b, c, d, e;
	int i=1;

	while (i<=4){
		scanf ("%lf %lf", &a, &b); // 75 25
		c=100-a; // 25
		d=c/100; // 0,25
		e=b/d; //100
	printf ("$%.2lf\n", e);
	i++;
	}
	
	return 0;
}
