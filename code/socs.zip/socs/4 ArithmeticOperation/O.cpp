#include<stdio.h>
int main ()
{
	int a, b;
	int i=1;
	while (i<5){
		scanf("%d %d", &a, &b);
		printf("%d\n", a*b);
	i++;
	}
	return 0;
}
