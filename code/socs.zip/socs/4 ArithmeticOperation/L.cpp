#include<stdio.h>
int main ()
{
	long int a, b;
	scanf ("%ld %ld", &a, &b);
	printf ("%d\n", a/b);
	return 0;
}
