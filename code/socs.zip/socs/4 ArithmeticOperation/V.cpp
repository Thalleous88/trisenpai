#include<stdio.h>
int main()
{
	double a, b,c,d,r,f,k;
	scanf("%lf", &a); getchar();
	scanf("%lf", &b); getchar();
	scanf("%lf", &c); getchar();
	scanf("%lf", &d); getchar();
	printf("%.2lf ",b*0.8);
	printf("%.2lf ",b*1.8+32);
	printf("%.2lf\n",b+273);
	printf("%.2lf ",c*0.8);
	printf("%.2lf ",c*1.8+32);
	printf("%.2lf\n",c+273);
	printf("%.2lf ",d*0.8);
	printf("%.2lf ",d*1.8+32);
	printf("%.2lf\n",d+273);

	return 0;
}
