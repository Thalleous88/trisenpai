#include<stdio.h>
int main ()
{
	double a, b, c;
	scanf ("%lf %lf", &a, &b);
	c=b/a;
	printf ("%.4lf%%\n", c*100);
	return 0;
}
