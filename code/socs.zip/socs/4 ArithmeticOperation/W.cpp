#include<stdio.h>
int main()
{
	int a, b;
	int i=1;
	while (i<=3){
		scanf("%d", &a);
		b=(a/10)%10;
		printf("%d\n", b);
	i++;
	}

	return 0;
}
