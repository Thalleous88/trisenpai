#include<stdio.h>
int main()
{
	int m, n;
	scanf("%d %d", &n, &m);
	int i=0;
	while(i<=m){
		printf("%d\n", n);
		n++;
	i++;
	}
	return 0;
}
