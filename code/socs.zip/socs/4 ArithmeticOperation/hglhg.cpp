#include<stdio.h>
#include<math.h>
int main()
{
	int a, b;
	scanf("%d", &a);
	b=pow(2,a);
	printf("%d\n", b-1);
	return 0;
}
