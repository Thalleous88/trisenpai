#include<stdio.h>
int main()
{
	int a;
	long long int b=0;
	scanf("%d", &a);	
	int i=1;
	while(i<=a){
		b=b+100+50*(i-1);
	i++;
	}
	printf("%lld\n", b);
return 0;
}
