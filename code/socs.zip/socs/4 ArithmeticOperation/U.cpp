#include<stdio.h>
int main()
{
	double t, a, b;
	int i=1;
	scanf("%d",&t);
	while(i<=3){
		scanf("%lf %lf", &a, &b);
		printf("%.2lf\n", a*b/360);
	i++;
	}
	return 0;
}
