#include<stdio.h>
int main ()
{
	char  a, b;
	scanf ("%c %c", &a, &b);
	int c = a;
	int d = b;
	printf ("%d\n", a*bo);
	return 0;
}
