#include<stdio.h>
int main ()
{
	int a;
	double b, c, d, e, f, g;
	scanf("%d", &a); getchar();
	scanf("%lf %lf", &b, &c); getchar();
	scanf("%lf %lf", &d, &e); getchar();
	scanf("%lf %lf", &f, &g); getchar();
	
	printf("%.2lf\n", (b/100)*c);
	printf("%.2lf\n", (d/100)*e);
	printf("%.2lf\n", (f/100)*g);
	return 0;
}
