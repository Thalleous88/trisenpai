#include<stdio.h>
int main()
{
	double a, b, c, d;
	scanf("%lf %lf %lf", &a, &b, &c);
	d=a*0.2+b*0.3+c*0.5;
	printf("%.2lf\n",d);
	return 0;
}
