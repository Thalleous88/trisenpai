#include<stdio.h>
int main ()
{
	double  a, b, c;
	int i=1;
	scanf ("%lf %lf", &a, &b);
	while (i<=3){
		c= a*b/100;
		a=a+c;
	i++	;
	}
	
	printf ("%.2lf\n", a);
	return 0;
}
