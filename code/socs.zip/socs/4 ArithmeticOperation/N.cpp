#include<stdio.h>
int main ()
{
	double a, b, n;
	scanf ("%lf %lf", &a, &b);
	n=((a-b)/a)*100;
	printf ("%.2lf%%\n", n);
	return 0;
}
