#include<stdio.h>
int main(){
	int n, c[101], q, x, y;
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%d", &c[i]);
	}
	scanf("%d", &q);
	for(int i=0;i<q;i++){
		scanf("%d %d", &x, &y);
		c[x-1]=y;
		printf("Case #%d:", i+1);
		for(int j=0;j<n;j++){
			printf(" %d", c[j]);
		}
		printf("\n");
	}
	return 0;
}
