#include<stdio.h>
int main(){
	int t, n, a;
	long long int result;
	int x[102][102];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){ //baris
			for(int k=0;k<n;k++){ //kolom
				scanf("%d", &x[j][k]);
			}
		}
		printf("Case #%d:", i);
		for(int j=0;j<n;j++){ //baris
			result=0;
			for(int k=0;k<n;k++){ //kolom
				result=result+x[k][j];
			}
			printf(" %lld", result);
		}
		printf("\n");
	}
	return 0;
}
