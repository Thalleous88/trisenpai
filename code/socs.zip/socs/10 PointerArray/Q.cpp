#include<stdio.h>
int main(){
	int t, n, m, q, visit;
	int room[100], a[100][100];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d %d", &n, &m, &q); //tmn, room, yg dtng
		for(int j=1;j<=m;j++){
			room[j]=0;
		}
		for(int j=1;j<=n;j++){
			for(int k=1;k<=m;k++){
				scanf("%d", &a[j][k]);
			}
		}
		for(int j=1;j<=q;j++){
			scanf("%d", &visit);
			for(int k=1;k<=m;k++){
				if(a[visit][k]==1){
					if(room[k]==0){
						room[k]=1;
					}else if(room[k]==1){
						room[k]=0;
					}
				}
			}
		}
		printf("Case #%d:\n", i);
		for(int j=1;j<=m;j++){
			(room[j]==0)?printf("NO\n"):printf("YES\n");
		}
	}
	
	return 0;
}
