#include<stdio.h>

int cekSame(int a[102][102], int n){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			for(int k=i+1;k<n;k++){
				if(a[i][j]==a[k][j])
				return 0;				
			}
		}
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			for(int k=j+1;k<n;k++){
				if(a[i][j]==a[i][k])
				return 0;
			}
		}
	}
	return 1;
}

int main(){
	int n, a[102][102];
	int count=0;
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &a[i][j]);
		}
	}
	(cekSame(a,n))?printf("Yay\n"):printf("Nay\n");
	return 0;
}
