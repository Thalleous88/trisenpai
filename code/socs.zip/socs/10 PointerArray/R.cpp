/* #include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int t, m;
	char from, to;
	char kata[1001];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%s", kata); getchar();
		scanf("%d", &m);
		for(int j=0;j<m;j++){
			scanf(" %c %c", &from, &to);getchar();
			for(int k=0;k<strlen(kata);k++){
				if(kata[k]==from){
					kata[k]=to;
				}
			}
		}
		printf("Case #%d: %s\n", i, kata);
	}
	return 0;
}
*/


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int t, m;
	char from[150], to[150];
	char kata[1001];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%s", kata); getchar();
		scanf("%d", &m);
		for(int j=0;j<m;j++){
			scanf(" %c %c", &from[j], &to[j]);getchar();
		}
		for(int k=0;k<m;k++){
			for(int j=0;j<strlen(kata);j++){
				if(kata[j]==from[k]){
					kata[j]=to[k];
				}
			}
		}
		printf("Case #%d: %s\n", i, kata);
	}
	return 0;
}

