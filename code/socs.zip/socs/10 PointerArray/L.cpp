#include<stdio.h>
int main(){
	int n, a[1002], b[1002];
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
	for(int i=0;i<n;i++){
		scanf("%d", &b[i]);
	}
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-1-i;j++){
			if(a[j]>a[j+1]){
				int temp=a[j];
				int temp2=b[j];
				a[j]=a[j+1];
				b[j]=b[j+1];
				a[j+1]=temp;
				b[j+1]=temp2;
			}
		}
	}
	for(int i=0;i<n;i++){
		printf("%d", b[i]);
		if(i!=n-1){
			printf(" ");
		} else {
			printf("\n");
		}
	}
	
	return 0;
}
