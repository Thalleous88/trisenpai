#include<stdio.h>
#include<string.h>
int main(){
	int t, j, k, temp;
	char kata[1001];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
			scanf("%s", kata);getchar();
		for(j=0, k=strlen(kata)-1;j<k;j++, k--){
			temp=kata[j];
			kata[j]=kata[k];
			kata[k]=temp;
		}
		printf("Case #%d : %s\n", i, kata);
	}
	return 0;
}
