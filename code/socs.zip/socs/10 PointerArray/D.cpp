#include<stdio.h>
int main(){
	int x, y, garden[101][101], a, b, c, t;
	scanf("%d %d", &x, &y);
	for(int i=0;i<x;i++){
		for(int j=0;j<y;j++){
			scanf("%d", &garden[i][j]);
		}
	}
	scanf("%d", &t);
	for(int k=0;k<t;k++){
		scanf("%d %d %d", &a, &b, &c);
		garden[a-1][b-1]=c;
	}
	for(int i=0;i<x;i++){
		for(int j=0;j<y;j++){
			printf("%d", garden[i][j]);
			if(j==y-1){
				printf("\n");
			}else{
				printf(" ");
			}
		}
	}
	return 0;
}

