#include<stdio.h>
int main(){
	int n, a[5010], happyCounter, count;
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);	
	}
	happyCounter=n; //set semuanya happy

	for(int i=0;i<n;i++){
		count=0;	
		for(int j=i;j<n;j++){
			if(i==j)continue;
			else{
				if(a[i]==a[j]){ //klo ada yg sama si dia ditandain ama dia nih, biar sedih
					count++;
				}
			}
		}
		if(count!=0)happyCounter--; //klo sedih ya happynya berkurang
	}
	printf("%d\n", happyCounter);
	
	return 0;
}
