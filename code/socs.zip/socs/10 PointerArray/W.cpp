#include<stdio.h>
int main(){
	int t, n, a[205], count, countt;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			scanf("%d", &a[j]);
		}
		countt=0;
		for(int j=0;j<n;j++){
			count=0;
			for(int k=0;k<n;k++){
				for(int l=k;l<n;l++){
					if(j==k||j==l||k==l)continue;
					else if(a[j]==a[k]+a[l]){
						count++;
					}
				}
			}
			if(count>0)countt++;
		}
		printf("Case #%d: %d\n", i, countt);
	}
	return 0;
}
