#include<stdio.h>

int main(){
	int t, a, b, as, bs, j, ans[100005]; 
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &a, &b);
		j=0;
		while(a>0 || b>0){ //99 999
			as=a%10; //9  9   0
			bs=b%10; //9  9   9
			ans[j]=(as+bs)%10; //8  8   9
			j++;
			a=a/10;//9  0
			b=b/10;//99  9
		}
		int kali=1;
		int result=0;
		for(int k=j-1;k>=0;k--, kali*=10){
			result=result+ans[k]*kali;
		}
		printf("Case #%d: %d\n", i, result);
	}
	
	return 0;
}
