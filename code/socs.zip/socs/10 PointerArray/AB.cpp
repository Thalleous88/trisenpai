#include<stdio.h>
int main(){
	int n, a[5001];
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
		
	}
	
	
	return 0;
}
