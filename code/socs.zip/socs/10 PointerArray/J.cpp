#include<stdio.h>
#include<string.h>
int main(){
	int t;
	char kata[1001];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%s", kata);
		printf("Case %d: ", i);
		for(int j=0;j<strlen(kata);j++){
			printf("%d", kata[j]);
			if(j<strlen(kata)-1){
				printf("-");
			}
		}
		printf("\n");
	}
	return 0;
}
