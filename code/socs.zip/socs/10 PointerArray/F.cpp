#include<stdio.h>
#include<string.h>

int main(){
	char usn[10000005];
	int j, k, i, t;
	scanf("%d", &t);
	for(i=1;i<=t;i++){
		int count=0;
		scanf("%s", usn);
		for(j=0;j<strlen(usn);j++){
			int counter=0;	
			for(k=j+1;k<strlen(usn);k++){
				if(usn[j]==usn[k]){
					counter++;
					break;
				}
			}
			if(counter==0)count++;
		}
		count%2==0?printf("Case #%d: Yay\n", i):printf("Case #%d: Ewwww\n", i);
	}
	return 0;
}
