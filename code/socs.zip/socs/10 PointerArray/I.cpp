#include<stdio.h>

void sort(int x[], int n){
	for(int i=0, j=n-1;i<j;i++, j--){
		int temp=x[i];
		x[i]=x[j];
		x[j]=temp;
	}
}


int main(){
	int t, n, x[1001];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			scanf("%d", &x[j]);
		}
		sort(x, n);
		printf("Case #%d:", i);
		for(int j=0;j<n;j++){
			printf(" %d", x[j]);
		}
		printf("\n");
	}
	return 0;
}
