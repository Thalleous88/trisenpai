#include<stdio.h>
int main(){
	int t, n, p, q; //testcase, total num, bibi, lili
	int a[10000];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			scanf("%d", &a[j]);
		}
		scanf("%d %d", &p, &q);
		if(a[p]==a[q]){
			printf("Case #%d : Draw\n", i);
		}
		else if(a[p-1]<a[q-1]){
			printf("Case #%d : Lili\n", i);	
		}
		else if(a[p-1]>a[q-1]){
			printf("Case #%d : Bibi\n", i);
		}
	} 
	return 0;
}
