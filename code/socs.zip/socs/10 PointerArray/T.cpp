#include<stdio.h>
#include<string.h>
int main(){
	int t;
	char kalimat[1001];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%s", kalimat);
		printf("Case #%d:\n", i);
		for(int j=0;j<strlen(kalimat); j++){
			if(kalimat[j]<'E'&&kalimat[j]>='A'){
				printf("A");
			}if(kalimat[j]<'I'&&kalimat[j]>='E'){
				printf("E");
			}if(kalimat[j]<'O'&&kalimat[j]>='I'){
				printf("I");
			}if(kalimat[j]<'U'&&kalimat[j]>='O'){
				printf("O");
			}if(kalimat[j]<='Z'&&kalimat[j]>='U'){
				printf("U");
			}
		}printf("\n");
		for(int j=0;j<strlen(kalimat); j++){
			if(kalimat[j]<'E'&&kalimat[j]>='A'){
				printf("%d", kalimat[j]-'A');
			}if(kalimat[j]<'I'&&kalimat[j]>='E'){
				printf("%d", kalimat[j]-'E');
			}if(kalimat[j]<'O'&&kalimat[j]>='I'){
				printf("%d", kalimat[j]-'I');
			}if(kalimat[j]<'U'&&kalimat[j]>='O'){
				printf("%d", kalimat[j]-'O');
			}if(kalimat[j]<='Z'&&kalimat[j]>='U'){
				printf("%d", kalimat[j]-'U');
			}
		}printf("\n");
	}
	return 0;
}
