#include<stdio.h>

int main(){
	int t, a, b, ans[100000];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &a, &b); getchar();
		if(a==0&&b==0){
			printf("Case #%d: %d\n", i, a+b);
		}
		else{
			int j=0;
			while(a>0||b>0){
				int as=a%10;
				int bs=b%10;
				ans[j]=(as+bs)%10;
				a=a/10;
				b=b/10;
				j++;
			}
			int kali=1;
			int result=0;
			for(int k=0;k<j;k++, kali=kali*10){
				result=result+ans[k]*kali;
			}
			printf("Case #%d: %d\n", i, result);
		}
	}
	
	return 0;
}
