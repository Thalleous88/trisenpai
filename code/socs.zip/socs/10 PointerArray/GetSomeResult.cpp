#include<stdio.h>
int main(){
	int t, a[100][100], b[100][100], c[100][100], n;
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		int ans[100][100]={0};
		int ans2[100][100]={0};
		scanf("%d", &n);
		//matrix 1
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				scanf("%d", &a[j][k]);
			}
		}
		//matrix 2
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				scanf("%d", &b[j][k]);
			}
		}
		//matrix 3
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				scanf("%d", &c[j][k]);
			}
		}
		printf("Case #%d:\n", i+1);
		for(int x=0;x<n;x++){
			for(int y=0;y<n;y++){
				for(int j=0;j<n;j++){
					ans[x][y]=ans[x][y]+a[x][j]*b[j][y];
				}
			}
		}
		for(int x=0;x<n;x++){
			for(int y=0;y<n;y++){
				for(int j=0;j<n;j++){
					ans2[x][y]=ans2[x][y]+ans[x][j]*c[j][y];
				}
				printf("%d", ans2[x][y]);
				if(y!=n-1)printf(" ");
			}
			printf("\n");
		}
	}
	return 0;
}
