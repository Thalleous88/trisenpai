#include<stdio.h>

void sortNum(int v[100003], int n){
	for(int i=0;i<n-1;i++) {
        for (int j= 0;j<n-i-1;j++) {
            if (v[j]<v[j+1]) {
                int temp=v[j];
                v[j]=v[j+1];
                v[j+1]=temp;
            }
        }
    }
}

int main(){
	int t, n, v[100003];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);		
		for(int j=0;j<n;j++){
			scanf("%d", &v[j]);
		}
		sortNum(v, n);	
		printf("Case #%d: %lld\n", i, v[0]+v[1]);
	}
	return 0;
}

/*
#include<stdio.h>
int main(){
	int t, n, v[100003], largest, largest2;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		largest=-1000000;
		largest2=-1000000;		
		for(int j=0;j<n;j++){
			scanf("%d", &v[j]);
			if(v[j]>largest){
				largest2=largest;
				largest=v[j];
			}
			else if(v[j]>largest2){
				largest2=v[j];
			}
		}		
		printf("Case #%d: %lld\n", i, largest+largest2);
	}
	return 0;
}
*/
