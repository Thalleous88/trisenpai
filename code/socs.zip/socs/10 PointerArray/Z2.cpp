#include<stdio.h>
int main(){
	int t, n, k, len;
	char nafas[10005];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &n, &k);
		scanf("%s", nafas);
		len=strlen(nafas);
		for(int j=0;j<n;j++){
			
		}
	}
	return 0;
}
