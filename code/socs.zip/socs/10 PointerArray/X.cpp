#include<stdio.h>
int main(){
	int t, n, m, a[505][505], hasil;
	long long int result;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &n, &m);
		for(int j=0;j<n;j++){
			for(int k=0;k<m;k++){
				scanf("%d", &a[j][k]);
			}
		}
		result=0;		
		for(int j=0;j<n;j++){
			hasil=0;
			for(int k=0;k<m;k++){
				if(hasil<a[j][k]){
					hasil=a[j][k];
				}
			}
			result=result+hasil;
		}
		printf("Case #%d: %lld\n", i, result);
	}
	return 0;
}
