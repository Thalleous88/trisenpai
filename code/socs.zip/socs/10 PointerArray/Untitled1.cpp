#include<stdio.h>
int main(){
	int t, n, k, breath;
	scanf("%d", &t);
	for (int i=1;i<=t;i++){
		scanf("%d %d", &n, &k);
		for(int j=0;j<n;j++){
			scanf("%d", &breath[i]);
		}
		for(int j)
	}
	return 0;
}
