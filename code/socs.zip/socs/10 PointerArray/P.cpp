#include<stdio.h>
int main(){
	int n, a[101][101];
	int count;
	int count2=0;
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		count=0;
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				scanf("%d", &a[j][k]);
				if(a[j][k]>=1)
					continue;
				 else{
					count++;
				}
			}	
		}
		if(count>0){
			count2++;
		}
	} printf("%d\n", count2);
	return 0;
}
