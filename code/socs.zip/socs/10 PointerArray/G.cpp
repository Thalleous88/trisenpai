#include<stdio.h>
int main(){
	int t, n, result;
	int x[10020], y[10020];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		result=0;
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			scanf("%d", &x[j]);
		}
		for(int j=0;j<n;j++){
			scanf("%d", &y[j]);
		}
		for(int j=0;j<n;j++){
			if(x[j]<y[j]){
				result++;
			}
		}
		printf("Case #%d: %d\n", i, result);
	}
	return 0;
}
