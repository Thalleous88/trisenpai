
/*
#include <stdio.h>
#include <string.h>

int main() {
    char str[1000];
    int count[26] = {0}; // Assuming you want to count lowercase alphabets

    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);

    for (int i = 0; i < strlen(str); i++) {
        if (str[i] >= 'a' && str[i] <= 'z') {
            count[str[i] - 'a'] = 1;
        }
    }

    int uniqueCount = 0;
    for (int i = 0; i < 26; i++) {
        if (count[i] == 1) {
            uniqueCount++;
        }
    }

    printf("Number of unique alphabets: %d\n", uniqueCount);

    return 0;
}
*/
