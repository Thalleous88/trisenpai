#include<stdio.h>

int main(){
	int t, n;
	long long int view[100000];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		view[1]=0;
		view[2]=1;
		for(int j=3;j<=n;j++){
			view[j]=view[j-1]+view[j-2];
		}
		printf("Case #%d: %lld\n", i, view[n]);
	}
	return 0;
}
