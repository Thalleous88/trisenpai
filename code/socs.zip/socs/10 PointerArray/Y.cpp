#include<stdio.h>
int main(){
	int t, q, l[1003], r[1003], k, m;
	char s[1003];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &q);
		scanf("%s", s); getchar();
		for(int j=0;j<q;j++){
			scanf("%d %d", &l[j], &r[j]);
			for(k=l[j]-1, m=r[j]-1;k<m;k++, m--){
				int temp=s[k];
				s[k]=s[m];
				s[m]=temp;
			}
		}
		printf("Case #%d: %s\n", i, s);
	}
	return 0;
}
