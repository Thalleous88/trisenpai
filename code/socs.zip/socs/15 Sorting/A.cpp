#include<stdio.h>
#include<math.h>
void sortNum(int a[100009], int t){
	for(int i=0;i<t-1;i++){
		for(int j=0;j<t-i-1;j++){
			if(a[j]>a[j+1]){
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}	
}


int main(){
	int t, a[100009];
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		scanf("%d", &a[i]);
	}
	sortNum(a, t);
	int max=0;
	for(int i=0;i<t-1;i++){
		if(abs(a[i]-a[i+1])>max){
			max=abs(a[i]-a[i+1]);
		}
	}
	int counter=0;
	for(int i=0;i<t-1;i++){
		if(counter!=0)printf(" ");
		if(abs(a[i]-a[i+1])==max){
			printf("%d %d", a[i], a[i+1]);
		}
		counter++;
	}
	printf("\n");	
	
	return 0;
}
