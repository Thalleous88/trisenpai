#include<stdio.h>

int main(){
	int t, n, x, a[505];
	long long int time;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &n, &x);
		for(int j=0;j<n;j++){
			scanf("%d", &a[j]);
		}
		
		time=0;
		for(int j=0;j<n;j++){
			for(int k=0;k<n-j-1;k++){
				if(a[k]>a[k+1]){
					int swap=a[k];
					a[k]=a[k+1];
					a[k+1]=swap;
					time++;
				}
			}
		}
		printf("Case #%d: %lld\n", i, time*x);
	}
	return 0;
}
