#include<stdio.h>

int main(){
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			scanf("%d")
		}
	}
	return 0;
}
