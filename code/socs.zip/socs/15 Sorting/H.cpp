#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main(){
	char temp2[250];
	int r, c;
	char str[250][250];
	scanf("%d %d", &r, &c);
	for(int i=0;i<r;i++){
		scanf("%s", str[i]); getchar();
	}
	
	for(int i=0;i<r;i++){
		for(int j=0;j<c;j++){
			for(int k=0;k<c-j-1;k++){
				if(tolower(str[i][k])>tolower(str[i][k+1])){
					int temp=str[i][k];
					str[i][k]=str[i][k+1];
					str[i][k+1]=temp;
				}
			}
		}
	}
	
	for(int i=0;i<r;i++){
		for(int j=0;j<r;j++){
			int x=0;
			while(tolower(str[j][x])==tolower(str[j+1][x])){
				x++;
			}
			if(tolower(str[j][x])<tolower(str[j+1][x])){
				strcpy(temp2, str[j]);
				strcpy(str[j], str[j+1]);
				strcpy(str[j+1], temp2);
			}
		}
	}
	
	for(int i=0;i<r;i++){
		printf("%s\n", str[i]);
	}
	return 0;
}
