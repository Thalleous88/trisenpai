#include<stdio.h>
#include<ctype.h>
#include<string.h>

struct list{
	char num[10];
	char name[45];
} plant[1010], temp;


int main(){
	int n;
	FILE *f;
	f=fopen("testdata.in", "r");
	fscanf(f, "%d", &n);
	for(int i=0;i<n;i++){
		fscanf(f, "%[^#]#%[^\n]\n", plant[i].num, plant[i].name);		
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n-i-1;j++){
			int k=0;
	  	     if (strcmp(plant[j].name, plant[j + 1].name) > 0) {
	            struct list temp = plant[j];
	            plant[j] = plant[j + 1];
	            plant[j + 1] = temp;
	        }
		}
	}
	for(int i=0;i<n;i++){
		printf("%s %s\n", plant[i].num, plant[i].name);
	}
	fclose(f);	
	return 0;
}
