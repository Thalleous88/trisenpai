#include<stdio.h>
int main(){
	int t, n, x[503][503];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				scanf("%d", &x[j][k]);
			}
		}
		printf("Case #%d:", i);
		for(int j=0;j<n;j++){
			int result=0;
			for(int k=0;k<n;k++){
				result=result+x[k][j];
			}
			printf(" %d", result);
		}
		printf("\n");
	}
	return 0;
}
