#include<stdio.h>

void printTriangel(int n){
	for(int i=n;i>0;i--){ //3 2 1
		for(int j=i-1;j>0;j--){ 
			printf(" ");
		}
		for(int j=i;j<=n;j++){ 
			printf("*");
		} printf("\n");
	}
}

int main(){
	int m, n;
	scanf("%d %d", &m, &n); //2 3
	for(int i=1;i<=m;i++){
		printTriangel(n);
	}
	return 0;
}
