#include<stdio.h>
#include<ctype.h>

int main(){
	int n, m, change;
	char kata[203];
	scanf("%d %d", &n, &m);
	scanf("%s", kata); getchar();
	for(int i=1;i<=m;i++){
		scanf("%d", &change);
		if(kata[change]>=65&&kata[change]<=90){
			kata[change]=tolower(kata[change]);
		}else if(kata[change]>=97&&kata[change]<=122){
			kata[change]=toupper(kata[change]);
		}
	}printf("%s\n", kata);
	return 0;
}
