#include<stdio.h>


int checkResult(int a[100005], int target, int low, int high){
    while(low<=high) {
        int mid=low+(high-low)/2;
        if(a[mid]==target){
            int result=mid;
            for (int b=mid-1;a[mid]==a[b]&& b>=0;b--){
                result = b;
            }
            return result+1;
        } else if (target>a[mid]) {
            low= mid+1;
        } else if (target<a[mid]) {
            high=mid-1;
        }
    }
    return -1;
}
/*
int checkResult(int a[100005], int target, int low, int high){
	if(high>=low){
		int mid=low+(high-low)/2;
		if (a[mid]==target){
			int result=mid;
			for(int b=mid-1;a[mid]==a[b];b--){
				result=b;
			}
			return result+1;
		}else if(target>a[mid]){
			return checkResult(a, target, mid+1, high);
		}else if(target<a[mid]){
			return checkResult(a, target, low, mid-1);
		}
	}
	return -1;
	
}
*/

int main(){
	int n,m,a[100005], q[100005];
	scanf("%d %d", &n, &m);
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
	for(int i=0;i<m;i++){
		scanf("%d", &q[i]);	
	}
	for(int i=0;i<m;i++){
		
		printf("%d\n", checkResult(a, q[i], 0, n-1));	
	}
	
	return 0;
}
