#include<stdio.h>

int main(){
	scanf("%d %d");
	
	return 0;
}
