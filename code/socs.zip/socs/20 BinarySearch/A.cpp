#include<stdio.h>

int checkResult(int n, int a[100005], int q){
	for(int i=0;i<n;i++){
		if(q==a[i])return i+1;
	}
	return -1;
}


int main(){
	int n,m,a[100005], q[100005];
	scanf("%d %d", &n, &m);
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
	for(int i=0;i<m;i++){
		scanf("%d", &q[i]);	
	}
	for(int i=0;i<m;i++){
		printf("%d\n", checkResult(n, a, q[i]));	
	}
	
	return 0;
}
