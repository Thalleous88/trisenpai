#include<stdio.h>

struct stud{
	char cde[35];
	char nme[35];
	char gnder[35];
	char papa[35];
	char mama[35];
	int sib;
};

struct lect{
	char code[35];
	char name[35];
	char gender[35];
	int stnum;
	struct stud stu[105];
}lec[105];

int main(){
	int n, k;
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%s", lec[i].code); getchar();
		scanf(" %[^\n]", lec[i].name); getchar();
		scanf("%s", lec[i].gender); getchar();
		scanf("%d", &lec[i].stnum); getchar();
		for(int j=0;j<lec[i].stnum;j++){
			scanf("%s", lec[i].stu[j].cde); getchar();
			scanf(" %[^\n]", lec[i].stu[j].nme); getchar();
			scanf("%s", lec[i].stu[j].gnder); getchar();
			scanf(" %[^\n]", lec[i].stu[j].papa); getchar();
			scanf(" %[^\n]", lec[i].stu[j].mama); getchar();
			scanf("%d", &lec[i].stu[j].sib); getchar();
		}
	}
	scanf("%d", &k);
	printf("Kode Dosen: %s\n", lec[k-1].code);
	printf("Nama Dosen: %s\n", lec[k-1].name);
	printf("Gender Dosen: %s\n", lec[k-1].gender);
	printf("Jumlah Mahasiswa: %d\n", lec[k-1].stnum);
	for(int j=0;j<lec[k-1].stnum;j++){
		printf("Kode Mahasiswa: %s\n", lec[k-1].stu[j].cde);
		printf("Nama Mahasiswa: %s\n", lec[k-1].stu[j].nme);
		printf("Gender Mahasiswa: %s\n", lec[k-1].stu[j].gnder);
		printf("Nama Ayah: %s\n", lec[k-1].stu[j].papa);
		printf("Nama Ibu: %s\n", lec[k-1].stu[j].mama);
		printf("Jumlah Saudara Kandung: %d\n", lec[k-1].stu[j].sib);	
	}
	return 0;
}
