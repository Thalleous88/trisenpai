#include <stdio.h>
#include <limits.h>

int cekCount(char x1, int y1, char x2, int y2, int counter) {
    if (x1 < 'A' || x1 > 'H' || y1 < 1 || y1 > 8 ||
        x2 < 'A' || x2 > 'H' || y2 < 1 || y2 > 8) {
        return INT_MAX;
    }

    if (x1 == x2 && y1 == y2) {
        return counter;
    }

    int move1 = cekCount(x1 + 2, y1 + 1, x2, y2, counter + 1);
    int move2 = cekCount(x1 + 2, y1 - 1, x2, y2, counter + 1);
    int move3 = cekCount(x1 - 2, y1 + 1, x2, y2, counter + 1);
    int move4 = cekCount(x1 - 2, y1 - 1, x2, y2, counter + 1);
    int move5 = cekCount(x1 + 1, y1 + 2, x2, y2, counter + 1);
    int move6 = cekCount(x1 + 1, y1 - 2, x2, y2, counter + 1);
    int move7 = cekCount(x1 - 1, y1 - 2, x2, y2, counter + 1);
    int move8 = cekCount(x1 - 1, y1 + 2, x2, y2, counter + 1);

    // Find the minimum among the valid moves
    int minMove = INT_MAX;
    if (move1 < minMove) minMove = move1;
    if (move2 < minMove) minMove = move2;
    if (move3 < minMove) minMove = move3;
    if (move4 < minMove) minMove = move4;
    if (move5 < minMove) minMove = move5;
    if (move6 < minMove) minMove = move6;
    if (move7 < minMove) minMove = move7;
    if (move8 < minMove) minMove = move8;

    return minMove;
}

int main() {
    int t, y1, y2;
    char x1, x2;
    scanf("%d", &t);
    for (int i = 1; i <= t; i++) {
        scanf(" %c%d %c%d", &x1, &y1, &x2, &y2);
        int counter = 0;
        int result = cekCount(x1, y1, x2, y2, counter);

        if (result == INT_MAX) {
            printf("Case #%d: Not reachable\n", i);
        } else {
            printf("Case #%d: %d\n", i, result);
        }
    }

    return 0;
}

