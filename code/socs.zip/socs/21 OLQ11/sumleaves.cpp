#include<stdio.h>

void countresult(int a[150], int n, int idx, int result){
	int left=idx*2;
	int right=(idx*2)+1;
	result = result + a[idx];
	if(left>n && right>n){
		printf("%d\n", result);
	}else{	
		if(left<=n){
			countresult(a, n, left, result);
		}
		if(right<=n){
			countresult(a, n, right, result);
		}
	}
}

int main(){
	int t, n, a[150];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=1;j<=n;j++){
			scanf("%d", &a[j]);
		}
		int result=0;
		printf("Case #%d:\n", i);
		countresult(a, n, 1, result);
	}
	return 0;
}



/*#include<stdio.h>

int countresult(int a[150], int n, int idx, int result){
	int left=idx*2;
	int right=(idx*2)+1;
	
	if(left>n && right>n){
		return 0;
	}
	
	if(left){
		if(left<=n){
			result = result + a[left]+ return countresult(a, n, left, result);			
		}if(left>n){
			printf("%d\n", result);
			return 0;
		}
	}
	if(right){
		if(right<=n){
			result = result + a[right] + return countresult(a, n, right, result);
		}if(right>n){
			printf("%d\n", result);
			return 0;
		}
	}
}

int main(){
	int t, n, a[150];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=1;j<=n;j++){
			scanf("%d", &a[j]);
		}
		int result=a[1];
		printf("Case #%d: %d\n", i, countresult(a, n, 1, result));
		;
	}
	return 0;
}*/
