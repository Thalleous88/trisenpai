#include<stdio.h>

int checkHorse(char x1, int y1, char x2, int y2, int counter){
	if(x1<='H' && x2<='H' && y1<=8 && y2<=8 && x1>='A' && x2>='A' && y1>=1 && y2>=1){
		if(x1==x2 && y1==y2 && counter < 6){
			return counter;
		}else{
			checkHorse(x1+2, y1+1, x2, y2, counter+1);
			checkHorse(x1+2, y1-1, x2, y2, counter+1);
			checkHorse(x1-2, y1+1, x2, y2, counter+1);
			checkHorse(x1-2, y1-1, x2, y2, counter+1);
			checkHorse(x1+1, y1+2, x2, y2, counter+1);
			checkHorse(x1+1, y1-2, x2, y2, counter+1);
			checkHorse(x1-1, y1-2, x2, y2, counter+1);
			checkHorse(x1-1, y1+2, x2, y2, counter+1);
		}	
	}
}


int main(){
	int t, y1, y2;
	char x1, x2;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%c%d", &x1, &y1); getchar();
		scanf("%c%d", &x2, &y2); getchar();
		int counter=0;
		printf("Case #%d: %d\n", i, checkHorse(x1, y1, x2, y2, counter));
	}
	return 0;
}
