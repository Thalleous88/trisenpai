#include<stdio.h>

int count, visited[20][20], n;

void cekKuda(char x1, int y1, char x2, int y2, int move){
	if(x1>'H' || x1<'A' || y1>8 || y1<1 || move>n*2){
		return;	
	}
	if(x1==x2 && y1==y2){
		count=1;
		return;
	}
	if(visited[x1-'A'][y1]==1){
		return;	
	} 
	visited[x1-'A'][y1]=1;
	cekKuda(x1+2, y1-1, x2, y2, move+1);
	cekKuda(x1+2, y1+1, x2, y2, move+1);
	cekKuda(x1-2, y1-1, x2, y2, move+1);
	cekKuda(x1-2, y1+1, x2, y2, move+1);
	cekKuda(x1+1, y1-2, x2, y2, move+1);
	cekKuda(x1-1, y1-2, x2, y2, move+1);
	cekKuda(x1-1, y1+2, x2, y2, move+1);
	cekKuda(x1+1, y1+2, x2, y2, move+1);
	
}

int main(){
	int n, t, y1, y2, move;
	char x1, x2;
	scanf("%d", &t); getchar();
	for(int i=1;i<=t;i++){
		scanf("%d", &n); getchar();
		scanf("%c%d %c%d", &x1, &y1, &x2, &y2); getchar();
		move=0;
		count=0;
		
		for(int j=0;j<8;j++){
			for(int k=0;k<8;k++){
				visited[j][k]=0;
			}
		}
		cekKuda(x1, y1, x2, y2, move);
		
		printf("Case #%d: ", i);
		if(count){
			printf("YES\n");
		}else{
			printf("NO\n");
		}		
	}
	return 0;
}
