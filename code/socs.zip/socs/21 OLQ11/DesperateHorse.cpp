#include<stdio.h>

int count, visited[100][100];

int cekCount(char x1, int y1, char x2, int y2, int counter){
	if(x1<='H' && y1<=8 && x1>='A' && y1>=1){
		if(x1==x2 && y1==y2 && counter < 6){
			return counter;
		}
		if(visited[x1-'A'][y1]>=counter){
			visited[x1-'A'][y1]=counter;
			
			cekCount(x1+2, y1+1, x2, y2, counter+1);
			cekCount(x1+2, y1-1, x2, y2, counter+1);
			cekCount(x1-2, y1+1, x2, y2, counter+1);
			cekCount(x1-2, y1-1, x2, y2, counter+1);
			cekCount(x1+1, y1+2, x2, y2, counter+1);
			cekCount(x1+1, y1-2, x2, y2, counter+1);
			cekCount(x1-1, y1-2, x2, y2, counter+1);
			cekCount(x1-1, y1+2, x2, y2, counter+1);	
		}
	}
}

int main(){
	int t, y1, y2;
	char x1, x2;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%c%d", &x1, &y1); getchar();
		scanf("%c%d", &x2, &y2); getchar();
		for(int j=0;j<8;j++){
			for(int k=0;k<8;k++){
				visited[i][j]=10000;
			}
		}
		int counter=0;
		printf("Case #%d: %d\n", i, cekCount(x1, y1, x2, y2, counter));
	}
	
	return 0;
}

