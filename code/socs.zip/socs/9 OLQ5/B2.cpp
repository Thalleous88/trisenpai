#include<stdio.h>

int checkPrime(int j){
	if(j<=1) return 0;
	for(int k=2;k*k<=j;k++){
		if(j%k==0) return 0;
	}
	return 1;
}

 int sumResult( int n){
	int sum=0;
	for(int j=2;j<=n;j++){
		if(n%j==0 && checkPrime(j)){
			sum+=j;
		}
	}
	return sum;
}

int main(){
	int t;
	int n;
	int result;
	scanf("%d", &t);
	for (int i=1;i<=t;i++){
		scanf("%d", &n);
		int result=sumResult(n);
		printf("Case #%d: %d\n", i, result);
	}
	return 0;
}
