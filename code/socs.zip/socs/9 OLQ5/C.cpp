#include<stdio.h>
int main(){
	int n;
	int m=1;
	int a[1001];
	scanf("%d", &n); getchar();
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]); getchar();
	}
	for(int i=0;i<n-1;i++){
		if(a[i]-a[i+1]==-1){
			m++;
		} else{
			printf("%d ", m);
			m=1;
		}	
	}
	printf("%d\n", m);
	return 0;
}


//		while(a[i]-a[i+1]==-1){
//			m++;
//		}
//	}
