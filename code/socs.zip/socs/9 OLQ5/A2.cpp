#include<stdio.h>
int main(){
	long long int t, k, jump; //k finishline
	scanf("%lld", &t);
	for(long long int i=1;i<=t;i++){
		long long int distance=0;
		scanf("%lld", &k);
		long long int jump=1;
		while(k>0){
			distance=distance+jump;
			if(distance>=k){
				printf("Case #%lld: %lld\n", i, jump); break;
			}
			jump++;
		}
		
	}
	return 0;
}
