#include<stdio.h>

void cekPrima(long int j, long int *result){
	long int x=0;
	for(long int k=1;k<=j;k++){
		if(j%k==0){
			x++;
		}
	}
	if(x==2){
		*result=*result+j;
		x=0;
	}
}

void pembagi(long int n, long int *result){
	for(long int j=2;j<=n;j++){
		if(n%j==0){ //cek j pembagiannya bkn
			cekPrima(j, result);
		}
	}	
}

int main(){
	int t; //testcase
	long int n, x, y; //num
	scanf("%d", &t);
	long int result=0;	
	for (int i=1;i<=t;i++){
		scanf("%ld", &n);
		pembagi(n, &result);
		printf("Case #%d: %ld\n", i, result);
		result=0;
	}
	return 0;
}
