#include<stdio.h>
int main(){
	long long int t, k, ans;
	scanf("%lld", &t); getchar();
	for(long long int i=1;i<=t;i++){
		long long int jump=0;
		long long int distance=0;
//		long long int j=0;
		scanf("%lld", &k); getchar(); //finishline
		while(distance>0){ //harusnya hingga jump >=k
			distance=distance+(distance+1);
			jump++;
			if(distance>=k)
				printf("Case #%lld: %lld\n", i, jump);
				break;
		}
		
	}
	return 0;
}
