#include<stdio.h>
int main(){
	int t, n;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		printf("Case #%d:\n", i);
		for(int j=1;j<=n;j++){
			if(j%5==0 && j%3==0){
				printf("%d Lili\n", j);
			} else if(j%5==0 || j%3==0){
				printf("%d Jojo\n", j);
			}
			else{
				printf("%d Lili\n", j);
			}
		}
	}
	return 0;
}
