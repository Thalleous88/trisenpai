#include<stdio.h>
int main(){
	int t, n, m;
	int hasil;
	int x[1005];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &n, &m);
		hasil=0;
		for(int j=0;j<n;j++){
			scanf("%d", &x[j]);
			hasil=hasil+x[j];
		}
		if(hasil>m){
			printf("Case #%d: Wash dishes\n", i);
		}
		else{
			printf("Case #%d: No worries\n", i);
		}
	}
	return 0;
}
