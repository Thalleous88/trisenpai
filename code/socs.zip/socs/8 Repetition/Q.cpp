#include<stdio.h>
int main(){
	long long int t, n, x, hasil;
	scanf("%lld", &t); getchar();
	for(int i=1;i<=t;i++){
		scanf("%lld %lld", &n, &x);
		if(n%2==0){
			if(n-x>=x){ 
				hasil=(x)/2;
			} else{ // 100 1
				hasil=(n-x+1)/2;
			} 
		}else{
			if(n-x>=x){ //5 4 >> 1 4
				hasil=x/2;
			} else{
				hasil=(n-x)/2;
			}
		}
		printf("Case #%d: %lld\n", i, hasil);
	}
	return 0;
}
