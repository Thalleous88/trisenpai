#include<stdio.h>
int main(){
	int t, a, b, c;
	int x=0;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d %d", &a, &b, &c);
		if(b>c){
			x++;
		}
	}
	printf("%d\n", x);
	return 0;
}
