#include<stdio.h>
#include<string.h>
int main(){
	int t;
	int titik=0;
	int angka=0;
	char s[101];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%[^\n]", s);
		for(int j=0;j<strlen(s);j++){
			if(s[j]=='.'){
				titik++;
			}else if(s[j]>='0'&&s[j]<='9'){
				angka++;
			}
		}
		if(titik==5&&angka==6&&s[1]=='.'&&s[3]=='.'&&s[5]=='.'&&s[7]=='.'&&s[9]=='.'){
			printf("Case #%d: YES\n", i);
		} else{
			printf("Case #%d: NO\n", i);
		}
	}
	return 0;
}
