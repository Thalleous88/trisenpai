#include<stdio.h> //untuk input output, # untuk processor, execute library
int main(){
	int n, m;
	scanf("%d %d", &n, &m); getchar();
	for(int i=0;i<=m;i++){
		printf("%d\n", n);
		n++;
	}
	return 0; 
}
