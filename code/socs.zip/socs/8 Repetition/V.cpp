#include<stdio.h>





int main(){
	int t, n;
	scanf("%d", &t); getchar();
	for(int i=1;i<=t;i++){
		scanf("%d", &n); getchar();
		if(n>1){
			for(int j=1;j<=n;j++){
				printf("*");
			}printf("\n");
			for(int k=1;k<=(n-2);k++){
				for(int l=1;l<=n;l++){
					if(l==1||l==n||l==(k+1)||(n-l+1)==(k+1)){
						printf("*");
					}
					else{
						printf(" ");
					}
				} printf("\n");
			}
		}
		for(int j=1;j<=n;j++){
			printf("*");
		}printf("\n\n");
	}
	return 0;
}
