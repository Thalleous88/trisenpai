#include<stdio.h>
int main(){
	int t;
	long long int result=0;
	long long int n[10002];
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		scanf("%lld", &n[i]);
		if(n[i]>0){
			result=result+n[i];
		}
	}
	printf("%lld\n", result);
}
