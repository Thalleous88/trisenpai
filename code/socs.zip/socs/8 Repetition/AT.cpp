#include<stdio.h>

void makeTriangel(int n){
	for(int j=n;j>0;j--){
		for(int k=1;k<j;k++){
			printf(" ");
		}
		for(int l=1;l<=2*(n-j)+1;l++){// 
			printf("*");
		}
	printf("\n");
	}
}

int main(){
	int t, n;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		makeTriangel(n);
	}
	return 0;
}
