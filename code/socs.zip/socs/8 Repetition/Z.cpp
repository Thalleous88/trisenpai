#include<stdio.h>
int main(){
	int n, k;
	int x=0;
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		scanf("%d", &k);
		x=x+k;
		if(x==12){
			x=28;
		} 
		if(x==30){
			x=10;
		}
		if(x==35){
			x=7;
		} 
		if(x>39){
			x=x-40;
		}
	}
	printf("%d\n", x);
	return 0;
}
