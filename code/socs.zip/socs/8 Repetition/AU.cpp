#include<stdio.h>

int main(){
	int t, n[101];
	char x='a';
	scanf("%d", &t);
	for(int i=1;i<=t; i++){
		scanf("%d", &n[i]);;
		printf("Case #%d: ", i);
		for(int j=1;j<=n[i];j++){
			printf("%c", x);
			x++;
		}
		x='a';
	printf("\n");
	}
	return 0;
}
 
