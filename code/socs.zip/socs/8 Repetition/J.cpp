#include<stdio.h>
int main(){
	int t, n;
	long long int a;
	scanf("%d", &t); getchar();
	for(int i=1;i<=t;i++){
		long long int result=0;
		scanf("%d", &n); getchar();
		for(int j=1;j<=n;j++){
			scanf("%lld", &a); getchar();
			result=result+a;
		}
		printf("Case #%d: %lld\n", i, result);
	}
	return 0;
}
