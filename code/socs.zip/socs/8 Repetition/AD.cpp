#include<stdio.h>
int main(){
	int n;
	int a[1001];
	int result[1001]={0};
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
		result[a[i]]++;
	}
	int largest=result[0];
	for(int i=0;i<n;i++){
		if(result[a[i]]>largest){
			largest=result[a[i]];
		}
	}
	printf("%d\n", largest);
	return 0;
}
