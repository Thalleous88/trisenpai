#include<stdio.h>
int main(){
	int t, n;
	long long int m, result, cheapest, candy[10002];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %lld", &n, &m);
		for(int j=0;j<n;j++){
			scanf("%lld", &candy[j]);
		}
		cheapest=candy[0];
		for(int j=1;j<n;j++){
			if(candy[j]<cheapest){
				cheapest=candy[j];
			}
		}
		result=m/cheapest;
		printf("Case #%d: %lld\n", i, result);
	}
	return 0;
}
