#include<stdio.h>
int main(){
	int t, n, k, m, x[102];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d %d", &n, &k, &m); //piring, max capacity, initial portion
		for(int j=0;j<n;j++){
			scanf("%d", &x[j]);
		}
		int result=m;
		for(int j=0;j<n;j++){
			if(x[j]>result && x[j]<=k){
				result=x[j];
			}
		}
		printf("Case #%d: %d\n", i, result);
	}
	return 0;
}
