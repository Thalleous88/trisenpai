#include<stdio.h>
int main(){
	long long int n, p;
	long long int hasil=0;
	long long int b[100002];
	scanf("%lld", &n); getchar();
	scanf("%lld", &p); getchar();
	for(int i=1;i<=n;i++){
		scanf("%lld", &b[i]); getchar();
		if(b[i]<p){
			hasil++;
		}
	}
	printf("%lld\n", hasil);
	return 0;
}
