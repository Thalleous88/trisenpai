#include<stdio.h>
int main(){
	int t, n;
	scanf("%d", &t);
	for (int i=1;i<=t;i++){
		scanf("%d", &n);
		int result=1;
		printf("Case %d: ", i);
		for(int j=1;j<=n;j++){
			printf("%d", result);
			result=result+j;
			j!=n?printf(" "):printf("\n");
		}
	}
	return 0;
}
