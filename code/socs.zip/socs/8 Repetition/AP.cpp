#include<stdio.h>
int main(){
	int t, n, k, arr[102];
	char str[102];
	scanf("%d", &t);
	for(int tc=1;tc<=t;tc++){
		scanf("%d %d", &n, &k);
		scanf("%s", str); getchar();
		//convert ke angka
		printf("Case #%d: ", tc);
		for(int i=0;i<n;i++){
			arr[i]=str[i]-97+k;
			while(arr[i]>25){
				arr[i]=arr[i]-26;
			}
			printf("%c", arr[i]+97);
		}
		printf("\n");
	}
	return 0;
}
