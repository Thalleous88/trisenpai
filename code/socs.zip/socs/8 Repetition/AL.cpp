#include<stdio.h>
int main(){
	long long int n, m, x[100000], y[100000];
	long long int count=0;
	long long int lx=x[0];
	long long int ly=y[0];
	scanf("%lld %lld", &n, &m);
	for(long long int i=0;i<n;i++){
		scanf("%lld", &x[i]);
	}
	for(long long int j=0;j<m;j++){
		scanf("%lld", &y[j]);
	}
	for(long long int i=0;i<n-1;i++){
		if(x[i]>lx){
			lx=x[i];
		}
	}
	for(long long int j=0;j<n-1;j++){
		if(y[j]>ly){
			ly=y[j];
		}
	}
	if(lx<=ly){
		printf("Secret debunked\n");		
	} else{
		printf("The dark secret was true\n");
	}
	return 0;
}
