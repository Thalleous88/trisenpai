#include<stdio.h>
int main(){
	int t, n;
	char s[101];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n); getchar();
		scanf("%[^\n]", s); getchar();
		printf("Case #%d: ", i);
		for(int j=0;j<n;j++){
			if(s[j]>='a'&& s[j]<='z'){
				printf("%c", s[j]);
			}
		}
		printf("\n");
	}
	return 0;
}
