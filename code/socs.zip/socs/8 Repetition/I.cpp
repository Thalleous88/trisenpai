#include<stdio.h>
int main(){
	int n, hasil, jo, li, bi, lawan;
	int hasilLawan=0;
	scanf("%d", &n); getchar();
	scanf("%d %d %d", &jo, &li, &bi);
	for (int i=1;i<=n;i++){
		scanf("%d", &lawan); getchar();
			hasilLawan=hasilLawan+lawan;
	}
	hasil=(hasilLawan+jo+li+bi)/(3+n);
	if(jo>=hasil){
		printf("Jojo lolos\n");
	}else {
		printf("Jojo tidak lolos\n");
	}
	if(li>=hasil){
		printf("Lili lolos\n");
	}else {
		printf("Lili tidak lolos\n");
	}
	if(bi>=hasil){
		printf("Bibi lolos\n");
	}else {
		printf("Bibi tidak lolos\n");
	}
	return 0;
}
