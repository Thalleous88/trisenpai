#include<stdio.h>

void checkDigit(long long int n, long long int *x){
	*x=0;
	while (n>0){
		n=n/10;
		(*x)++;
	}
}

int main(){
	long long int t, n;
	long long int x=0;
	scanf("%lld", &t);
	for(long long int i=1;i<=t;i++){
		scanf("%lld", &n);
		checkDigit(n, &x);
	printf("Case #%lld: %lld\n", i, x);
	}
	return 0;
}
