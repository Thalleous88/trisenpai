#include<stdio.h>
#include<string.h>
int main(){
	int t, n, score;
	char s[101], k[101];
	int l=0;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		scanf("%s", s);
		scanf("%s", k);
		for(int j=0;j<n;j++){
			if(s[j]==k[j]){
				l++;
			}
		}
		score=l*100/n;
		printf("Case #%d: %d\n", i, score);
		l=0;
	}
	return 0;
}
