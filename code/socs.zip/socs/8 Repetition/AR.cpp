#include<stdio.h>
int main(){
	int m, n;
	scanf("%d %d", &m, &n);
	for(int i=1;i<=m;i++){
		for(int j=1;j<=n;j++){
			for(int k=0;k>=j-1;k--){
				printf(" ");
			}
			for(int l=0;l<=j-1;l++){
				printf("*");
			}
			printf("\n");
		}
	}
	return 0;
}
