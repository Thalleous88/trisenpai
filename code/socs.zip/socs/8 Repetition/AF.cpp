#include<stdio.h>
void cobaHitung(int a[200], int *on, int *off, int n){
	int result;
	for(int i=0;i-1<n;i++){
		for(int j=i+1;j<n;j++){
			result=a[i]^a[j];
			int counter1=0;
			int counter2=0;
			while(result>0){
				int b=result%2;
				b==1?counter1++:counter2++;
				result=result/2;
			}
			counter1>=3?(*on)++:(*off)++;
		}
	}
}

int main(){
	int t, n, a[200];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		int on=0;
		int off=0;
		for(int j=0;j<n;j++){
			scanf("%d", &a[j]);
		}
		cobaHitung(a, &on, &off, n);
		printf("Case #%d: %d %d\n", i, on, off);
	}
	return 0;
}
