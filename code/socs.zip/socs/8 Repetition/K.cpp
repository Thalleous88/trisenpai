#include<stdio.h>
int main(){
	int t, n;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		printf("Case #%d:\n", i);
		for(int j=1;j<=n;j++){ //1, 2, 3, 4, 5
			for(int k=j;k<n;k++){ //
				printf(" ");
			}
			for(int l=1;l<=j;l++){
				if((n+l)%2==0){
					printf("*");
				}
				else{
					printf("#");
				}
			}
		printf("\n");
		}
	}
	return 0;
}
