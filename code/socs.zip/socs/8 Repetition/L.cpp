#include<stdio.h>
int main(){
	int t, a, b, x, y;
	int result=0; // a bottle u have
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &a, &b); //3 2
		while(a>=b){
			x=a/b; //3/2=1 || 2/2=1
			result=result+(x*b); //bottle u get //0+2=2 || 2+2=4
			y=a%b; //bottle sisanya //1||0
			a=x+y;//2 ||1+1=2||1+0=1
		}
		result=result+x; //
		printf("Case #%d: %d\n", i, result);
		result=0;
	}
	return 0;
}
