#include<stdio.h>
int main(){
	int t, n, a[1001];
	int result=0;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			scanf("%d", &a[j]);
		}
		int largest=a[0];
		for(int j=1;j<n;j++){
			if(a[j]>largest){
				largest=a[j];
			}
		}
		for(int j=0;j<n;j++){
			if(a[j]==largest){
				result++;
			}
		}
	printf("Case #%d: %d\n", i, result);
	result=0;
	}
}
