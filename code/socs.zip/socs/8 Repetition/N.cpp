#include<stdio.h>
int main(){
	int t, a, b;
	int hasil;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &a, &b);
		hasil=a;
		while(a>=b){
			int x=a/b; //yg bisa dituker
			int y=a%b;
			result=result+
			
		}	
	}
	return 0;
}
