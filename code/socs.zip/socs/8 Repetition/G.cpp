#include<stdio.h>
int main(){
	int n, x;
	int result=0;
	scanf("%d", &n); getchar();
	for(int i=1;i<=n;i++){
		scanf("%d", &x); getchar();
		result=result+x;
	}
	printf("%d\n", result);
	return 0;
}
