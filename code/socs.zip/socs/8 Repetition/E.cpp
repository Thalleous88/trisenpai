#include<stdio.h>
int main(){
	int t, p, a, j, x, digit[100];
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		scanf("%d %d", &x, &p);
		j=0;
		while(x>0){
			a=x%2;
			digit[j]=a;
			j++;
			x=x/2;
		}
		printf("%d\n", digit[p]);
	}
	return 0;
}
