#include<stdio.h>
int main(){
	int t, n, m; // n height m width
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &n, &m); getchar();
		printf("Case #%d:\n", i);
		for(int j=1;j<=m;j++){
			printf("#");
		} printf("\n");
		for(int k=1;k<=(n-2);k++){
			for (int l=1;l<=m;l++){
				if(l==1||l==m){
					printf("#");
				}else{
					printf(" ");
				}
			} printf("\n");
		}
		for(int j=1;j<=m;j++){
			printf("#");
		} printf("\n");
	}
	return 0;
}
