#include<stdio.h>
int main(){
	int n;
	scanf("%d", &n);
	int count=0;
	for(int j=0;j<=n;j++){
		for(int b=0;b<=n;b++){
			int l=n-j-b;
			if(l>=0 && l<=n) count++;
		}
	}
	printf("%d\n", count);
	return 0;
}
