#include<stdio.h>
int main(){
	int t, n[1000];
	long long int result=0;
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		scanf("%d", &n[i]);
		result=result+n[i];
	}
	printf("%lld\n", result);
	return 0;
}
