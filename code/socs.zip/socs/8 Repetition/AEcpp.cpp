#include<stdio.h>
int main(){
	int t;
	double r, h, lingkaran, selimut, hasil;
	double p=3.14;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%lf %lf", &r, &h);
		lingkaran=p*r*r;
		selimut=2*p*r*h;
		hasil=selimut+lingkaran*2;
		printf("Case #%d: %.2lf\n", i, hasil);
	}
	
	return 0;
}
