#include<stdio.h>
int main(){
	int t, n;
	int a[1001];
	scanf("%d", &t); getchar();
	for(int i=1;i<=t;i++){
		scanf("%d", &n); getchar();
		int even=0;
		int odd=0;
		for(int j=0;j<n;j++){
			scanf("%d", &a[i]); getchar();
			if(a[i]%2==0){
				even++;
			}else{
				odd++;
			}
		}
	printf("Odd group : %d integer(s).\n", odd);
	printf("Even group : %d integer(s).\n\n", even);
	}
	return 0;
}
