#include<stdio.h>
int main(){
	int t, n;
	int b=0;
	int l=0;
	char s[101];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		scanf("%s", s);
		for(int j=0;j<n;j++){
			if(s[j]=='L'){
				l++;
			}
			else if(s[j]=='B'){
				b++;
			}
		}
		if(l==b){
			printf("None\n");
		}
		if(l>b){
			printf("Lili\n");
		}
		if(l<b){
			printf("Bibi\n");
		}
		b=0;
		l=0;
	}
	return 0;
}
