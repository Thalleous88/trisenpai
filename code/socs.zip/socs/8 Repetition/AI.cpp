#include<stdio.h>
int cekSplit(int n, int x[100005]){
	for(int i=1;i<n-1;i++){
		int counta=0;
		int countb=0;	
		for(int j=0;j<i;j++){
			counta=counta+x[j];
		}
		for(int j=i;j<n;j++){
			countb=countb+x[j];
		}
		if(counta==countb){
			return 1;
		}
	}
	return 0;
}

int main(){
	int t, n, x[100005];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		for(int j=0;j<n;j++){
			scanf("%d", &x[j]);
		}
		printf("Case #%d: ", i);
		cekSplit(n, x)?printf("Yes\n"):printf("No\n");
	}
	return 0;
}
