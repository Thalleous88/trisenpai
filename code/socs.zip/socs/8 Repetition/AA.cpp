#include<stdio.h>
int main(){
	int n, k;
	int last=0;
	scanf("%d", &n);
	for(int i=1;i<=n;i++){
		scanf("%d", &k);
		last=last+k;
		if(last==9){
			last=21;
		} else if(last==33){
			last=42;
		} else if(last==76){
			last=92;
		} else if(last==53){
			last=37;
		} else if(last==80){
			last=59;
		} else if(last==97){
			last=88;
		}
	} printf("%d\n", last);
	return 0;
}
