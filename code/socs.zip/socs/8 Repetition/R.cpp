#include<stdio.h>
int main(){
	int t, n, result;
	int x[2002];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		result=0;
		for(int j=0;j<n;j++){
			scanf("%d", &x[j]);
			if(result<x[j])result=x[j];
		}
		for(int j=0;j<n-1;j++){
			if(x[j]>x[j+1] && x[j]-x[j+1]<result)result=x[j]-x[j+1];			
			if(x[j]<=x[j+1] && x[j+1]-x[j]<result)result=x[j+1]-x[j];			
		}
		printf("Case #%d: %d\n", i, result);
	}
	return 0;
}
