#include<stdio.h>
int main(){
	int n, k;
	scanf("%d %d", &n, &k);
		for (int j=1;j<=n;j++){ //baris
			for (int l=1;l<=n;l++){ //kolom
				printf("#");
			}
		printf("\n");
		} 
		printf("\n");
		for (int j=1;j<=n;j++){ //baris
			for (int l=1;l<=n;l++){ //kolom
				if(j%k==0){
					printf("#");
				} else{
					printf(".");
				}	
			}
		printf("\n");
		} 
		printf("\n");
		for (int j=1;j<=n;j++){ //baris
			for (int l=1;l<=n;l++){ //kolom
				if(l%k==0){
					printf("#");
				} else{
					printf(".");
				}	
			}
		printf("\n");
		} 		
	//	for (int j=1)
	return 0;
}
