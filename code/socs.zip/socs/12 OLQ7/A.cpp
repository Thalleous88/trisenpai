#include<stdio.h>
int main(){
	int t, count, counttt, a[105][105];
	counttt=0;	
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		for(int j=0;j<t;j++){
			scanf("%d", &a[i][j]);
		}
	}
	for(int i=0;i<t;i++){
	count=0;		
		for(int j=0;j<t;j++){
			if(a[i][j]>=1 && a[i][j]<=t){
				count++;
			}
		}
		if(count!=t){
			counttt++;	
		}	
	}
	printf("%d\n", counttt);	
	return 0;
}
