#include<stdio.h>
#include<string.h>
int main(){
	int t, len, count, j, k;
	char s[505];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%s", s);
		count=0;
		len=strlen(s);
		for(j=0, k=len-1;j<k;j++,k--){
			if(s[j]!=s[k]) count++;
		}
		count>0?printf("Case #%d: Nah, it's not a palindrome\n", i):printf("Case #%d: Yay, it's a palindrome\n", i);
	}
}
