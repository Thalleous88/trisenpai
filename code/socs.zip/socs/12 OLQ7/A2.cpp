#include<stdio.h>
int main(){
	int t, a[105][105];
	int count[105]={0};
	int counttt=0;	
	scanf("%d", &t);
	for(int i=0;i<t;i++){
		for(int j=0;j<t;j++){
			scanf("%d", &a[i][j]);
		}
	}
	for(int i=0;i<t;i++){		
		for(int j=0;j<t;j++){
			count[a[i][j]]++;
		}	
	}
	for(int i=1;i<=t;i++){
		if(count[i]<t) counttt++;
	}
	printf("%d\n", counttt);	
	return 0;
}
