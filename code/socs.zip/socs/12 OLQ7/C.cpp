#include<stdio.h>
#include<string.h>
int main(){
	int t, len, j, k;
	char kalimat[1005];
	scanf("%d", &t); getchar();
	for(int i=1;i<=t;i++){
		for(j=0;kalimat[j-1]!='\n';j++){
			scanf("%c", &kalimat[j]);
			if(kalimat[j]=='\n')
			kalimat[j]='\0';
			break;
		}
		len=strlen(kalimat);
		for(j=0,k=len-1;j<k;j++,k--){
			int temp=kalimat[j];
			kalimat[j]=kalimat[k];
			kalimat[k]=temp;
		}
		printf("Case #%d: %s\n", i, kalimat);
	}
	return 0;
}
