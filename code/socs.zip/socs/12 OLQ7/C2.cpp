#include<stdio.h>
#include<string.h>
int main(){
	int t, l, j, k, len;
	char kalimat [1005];
	scanf("%d", &t); getchar();
	for(int i=1;i<=t;i++){
 		l=0;
        while(1){
            scanf("%c", &kalimat[l]);
            if (kalimat[l]=='\n'||kalimat[l]==EOF) {
                kalimat[l]='\0'; 
                break;
            }l++;
        }
		len=strlen(kalimat);
		for(j=0,k=len-1;j<k;j++,k--){
			int temp=kalimat[j];
			kalimat[j]=kalimat[k];
			kalimat[k]=temp;
		}
		printf("Case #%d: %s\n", i, kalimat);
	}
	return 0;
}
