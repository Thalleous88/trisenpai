#include<stdio.h>

int isCubic(int x){
	if(x==1)return 1;
	for(int j=0;j<x;j++){
		if(j*j*j==x)return 1;
	}
	return 0;
}

int isSquare(int x){
	if(x==1)return 1;
	for(int j=0;j<x;j++){
		if(j*j==x)return 1;
	}
	return 0;
}

int isPrime(int x){
	if(x==1)return 0;
	for(int j=2;j<x;j++){
		if(x%j==0)return 0;
	}
	return 1;
}

int main(){
	int t, x;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &x);
		printf("Case #%d :", i);
		if(isPrime(x)){
			printf(" prime");
		}
		if(isSquare(x)){
			printf(" square");			
		}
		if(isCubic(x)){
			printf(" cubic");			
		}
		if(!isPrime(x) && !isSquare(x) && !isCubic(x)){
			printf(" none");			
		}
		printf("\n");
	}
	return 0;
}
