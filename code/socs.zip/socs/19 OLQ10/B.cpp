#include<stdio.h>
#include<string.h>
#include<ctype.h>

int main(){
	int t;
	char s[1010];
	scanf("%d", &t); getchar();
	for(int i=1;i<=t;i++){
		scanf("%[^\n]", s); getchar();
		printf("Case #%d: ", i);
		for(int j=0;j<strlen(s);j++){
			if(tolower(s[j])!='a' && tolower(s[j])!='e' && tolower(s[j])!='i' && tolower(s[j])!='o' && tolower(s[j])!='u')printf("%c", s[j]);
		}printf("\n");
	}	
	return 0;
}
