#include<stdio.h>

long long int countRev(long long int num){
	long long int count=0;
	while(num>0){
		int a=num%10;
		count=count*10+a;
		num=num/10;
	}
	return count;
}

int main(){
	int t;
	long long int num1, num2;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%lld", &num1);
		num2=countRev(num1);
		printf("Case #%d: %lld\n", i, num1+num2);
	}
	
	return 0;
}
