#include<stdio.h>

int main(){
	int t, a, b, n;
	char str[10010];
	FILE *f;
	f=fopen("testdata.in", "r");
	fscanf(f, "%d", &t);
	for(int i=1;i<=t;i++){
		int counter=0;
		fscanf(f, "%d %d %d", &n, &a, &b); 
		fscanf(f, "%s\n", str);
		for(int j=0;j<n;j++){
			int count=0;
			while(str[j]=='1'){
				count++;
				j=j+1;
			}
			if(count>=a && count<=b){
				counter++;
			}			
		}printf("Case #%d: %d\n", i, counter);
	}
	fclose(f);
	return 0;
}
