#include<stdio.h>
//SALAH
int length(long long int li){
	int count=1;;
	while(li>0){
		li=li/10;
		count=count*10;;
	}
	return count/10;
}

long long int countRev(long long int li){
	long long int counter=0;
	int c=length(li);
	for(int i=c;li>0;i/=10){
		int a=li%10;
		counter=counter+a*i;
		li=li/10;
	}
	return counter;
}

int main(){
	int t;
	long long int li, bi;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%lld", &li);
		bi=countRev(li);
		printf("Case #%d: %lld\n", i, li+bi);
	}
	return 0;
}
