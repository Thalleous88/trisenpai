#include<stdio.h>
int main()
{
	int x;
	scanf("%d", &x);
	int i=1;
	while (i<=3){
		long int a, b;
		scanf("%ld %ld", &a, &b);
		printf("%ld\n", (a/b<<b));
	i++;
	}
	return 0;
}
