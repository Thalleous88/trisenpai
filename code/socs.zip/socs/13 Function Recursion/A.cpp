#include<stdio.h>

int cekCoba(int n, int *count){
	if(n==0){
		n=1; return n;
	}
	else if(n==1){
		n=2; return n;
	}
	else if(n%5==0){
		if(n%3==0)(*count)++;		
		return n*2;
	}
	else{
		if(n%3==0)(*count)++;
		return cekCoba(n-1, count)+n+cekCoba(n-2, count)+n-2;
	}
}

int main(){
	int t, n;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		int count=0;
		scanf("%d", &n);
		int result=cekCoba(n, &count);
		printf("Case #%d: %d %d\n", i, result, count);
	}
	return 0;
}
