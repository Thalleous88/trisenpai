#include<stdio.h>
int cekCoba(int n, int *count){
	if(n==1)return n;
	else if(n%2!=0){
		(*count)++;
		return cekCoba(n-1, count)+cekCoba(n+1, count);
	}
	else{
		(*count)++;
		return cekCoba(n/2, count);
	}
}

int main(){
	int t, n;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		int count=0;
		scanf("%d", &n);
		printf("Case #%d: %d\n", i, cekCoba(n, &count));
	}
	return 0;
}
