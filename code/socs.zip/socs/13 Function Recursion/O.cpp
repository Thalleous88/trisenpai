#include<stdio.h>

int visited[150][150];
int count;
char map[150][150];

void countEat(int i, int j){	
	if(i<0 || j<0){
		return;
	}
	
	visited[i][j]=1;
	if(map[i][j]=='*'){
		count++;
	}
	if(map[i+1][j]!='#' && visited[i+1][j]==0){
		countEat(i+1, j);
	}
	if(map[i-1][j]!='#' && visited[i-1][j]==0){
		countEat(i-1, j);
	}
	if(map[i][j+1]!='#' && visited[i][j+1]==0){
		countEat(i, j+1);
	}
	if(map[i][j-1]!='#' && visited[i][j-1]==0){
		countEat(i, j-1);
	}
}

int main(){
	int t, n, m;
	
	scanf("%d", &t);
	
	for(int i=1;i<=t;i++){
		
		scanf("%d %d", &n, &m);
		
		for(int j=0;j<n;j++){
			//for(int k=0;k<m;k++){
				scanf("%s", map[j]);
			//}
			getchar();
		}
		
		for(int j=0;j<n;j++){
			for(int k=0;k<m;k++){
				visited[j][k]=0;
			}
		}
		
		for(int j=0;j<n;j++){
			for(int k=0;k<m;k++){
				count=0;
				if(map[j][k]=='P'){
					countEat(j, k);
					break;
				}
			}
			if(count!=0){
				break;
			}
		}
		
		printf("Case #%d: %d\n", i, count);
	}
	return 0;
}
