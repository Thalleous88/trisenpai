#include<stdio.h>
#include<string.h>
int cekPal(char kata[1050]){
	int len=strlen(kata);
	for(int i=0, j=len-1;i<j;i++, j--){
		if(kata[i]!=kata[j])return 0;
	} 
	return 1;
}

int main(){
	int t;
	char kata[1050];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%s", kata);
		!cekPal(kata)?printf("Case #%d: no\n", i):printf("Case #%d: yes\n", i);
	}	
	return 0;
}
