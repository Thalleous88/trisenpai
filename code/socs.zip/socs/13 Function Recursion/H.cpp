#include<stdio.h>
int fibo(int n, char a, char b){
	if(n==0){
		printf("%c", a);
		return n;
	}
	else if(n==1){
		printf("%c", b);
		return n;		
	}
	else{
		return fibo(n-1, a, b)+fibo(n-2, a, b);
	}
}

int main(){
	int t, n;
	char a, b;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %c %c", &n, &a, &b);
		printf("Case #%d: ", i);
		fibo(n, a, b);	
		printf("\n");	
	}
	return 0;
}
