#include<stdio.h>

int periksa(int n, int *count){
	(*count)++;
	if(n==1) return 1;
	else if(n%2==0) return periksa(n/2, count);
	else return periksa(n*3+1, count);
}

int main(){
	int t, n;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		int count=0;
		scanf("%d", &n);
		periksa(n, &count);
		(count-1)%2==0?	printf("Case #%d: Lili\n", i):printf("Case #%d: Jojo\n", i);
	}
	return 0;
}




/*

#include<stdio.h>

int periksa(int n, int *count){
	(*count)++;
	if(n==1) return n;
	else if(n%2==0) return periksa(n/2, count);
	else return periksa(n*3+1, count);
}

int main(){
	int t, n;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		int count=0;
		scanf("%d", &n);
		periksa(n, &count);
		(count-1)%2==0?	printf("Case #%d: Lili\n", i):printf("Case #%d: Jojo\n", i);
	}
	return 0;
}
