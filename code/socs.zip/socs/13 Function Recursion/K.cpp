#include<stdio.h>
int fibo(int i, int j, int n){
	if(n==0){
		return i;
	}
	else if(n==1){
		return j;
	}
	else{
		return fibo(i, j, n-1)+fibo(i, j, n-2);
	}
}

int main(){
	int i, j, n;
	scanf("%d %d", &i, &j);
	scanf("%d", &n);
	printf("%d\n", fibo(i, j, n));
	return 0;
}
