#include<stdio.h>
int periksa(int m, int n){
	if(m==0) return n+1;
	else if(m>0 && n==0) return periksa(m-1, 1);
	else if(m>0 && n>0) return periksa(m-1, periksa(m, n-1));
}

int main(){
	int m, n;
	scanf("%d %d", &m, &n);
	printf("result: %d\n", periksa(m, n));
	return 0;
}
