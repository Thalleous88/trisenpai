#include<stdio.h>
long long int fibo(int n, int x, int y){
	if(n==0) return x;
	else if (n==1) return y;
	else return fibo(n-1, x, y)-fibo(n-2, x, y);
}

int main(){
	int t, n, x, y;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d %d", &n, &x, &y);
		printf("Case #%d: %lld\n", i, fibo(n, x, y));
	}
	return 0;
}
