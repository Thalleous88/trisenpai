#include<stdio.h>

int AtoB(int a, int b){
	if(a==b) return 1;
	else if(a==1) return 0;
	else{
		if(a%2!=0) return AtoB(a*3+1, b);
		else return AtoB(a/2, b);
	}	
}

int main(){
	int t, a, b;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d %d", &a, &b);
		if(AtoB(a, b)){
			printf("Case #%d: YES\n", i);
		}else{
			printf("Case #%d: NO\n", i);
		}
	}
	return 0;
}
