#include<stdio.h>

int periksa(int n, long long int *count){
	(*count)++;
	if(n==1){
		n=1;
		return n;
	}
	if(n==0){
		n=0;
		return n;
	}
	else{
		return periksa(n-1, count)+periksa(n-2, count);
	}
}

int main(){
	int t, n;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		long long int count=0;
		periksa(n, &count);
		printf("Case #%d: %lld\n", i, count);
	}
	return 0;
}
