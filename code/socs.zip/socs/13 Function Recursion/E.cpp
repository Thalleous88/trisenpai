#include<stdio.h>

int main(){
	int t, n, a[1005];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d",&n);
		long long int result=0;
		for(int j=0;j<n;j++){
			scanf("%d", &a[j]);
			result=result+a[j];
		}
		printf("Case #%d: %lld\n", i, result);
	}
	return 0;
}
