//#include<stdio.h>
//#include<string.h>
//int main(){
//	int t, i, N, j, k, l;
//	int matriks[3][N][N];
//	scanf("%d", &t); getchar(); //banyak tc
//	for(i=1;i<=t;i++){ //banyaknya tc
//		scanf("%d", &N); getchar(); //ukuran matriks
//		for(j=1;j<=N;j++){
//			for(k=1;k<=N;k++){
//				scanf("%d", &matriks[j][k][l]); getchar();
//			}
//		} printf("\n");
//	}
//	return 0;
	

#include <stdio.h>
#include <string.h>

int main(){
	int tc,size;
	scanf("%d",&tc);getchar();
	for(int i=1;i<=tc;i++){
		scanf("%d",&size); getchar();
		int matrix[3][size][size];
		int res[size][size];
		
		for(int j=0;j<3;j++){
			for(int k=0;k<size;k++){
				for(int l=0;l<size;l++){
					scanf("%d",&matrix[j][k][l]);getchar();
					
				}
			}
			
		}
		for(int a=0;a<size;a++){
			for(int b=0;b<size;b++){
				res[a][b]=0;
				for(int l=0;l<size;l++){
					printf("[%d %d] %d+=%d*%d\n",b,a,res[a][b],matrix[0][a][l],matrix[1][l][b]);
					res[a][b]+=matrix[0][a][l]*matrix[1][l][b];
				}
			}
		}
		for(int a=0;a<size;a++){
			for(int b=0;b<size;b++){
				matrix[0][a][b]=0;
				for(int l=0;l<size;l++){
					printf("[%d %d] %d+=%d*%d\n",b,a,matrix[0][a][b],res[a][l],matrix[2][l][b]);
					matrix[0][a][b]+=res[a][l]*matrix[2][l][b];
				}
				printf("%d ",res[a][b]);
			}
		}
		
		
		
		
		
	}
	return 0;
}

/*
	
	This code appears to be a C program that performs matrix multiplication and manipulation. Let me explain it step by step:

Include necessary header files:

c
Copy code
#include <stdio.h>
#include <string.h>
This code includes the standard input/output library (stdio.h) for input and output functions and the string library (string.h) for string manipulation functions, although the string library is not used in this code.

Define the main function:

c
Copy code
int main(){
This is the main function of the program, where execution begins.

Declare variables:

c
Copy code
int tc, size;
These variables will be used to store the number of test cases (tc) and the size of matrices (size) input by the user.

Read the number of test cases:

c
Copy code
scanf("%d", &tc);
getchar();  // Consume the newline character
The program reads the number of test cases from the user and uses getchar() to consume the newline character left in the input buffer.

Loop through each test case:

c
Copy code
for (int i = 1; i <= tc; i++) {
This loop iterates through each test case.

Read the size of matrices:

c
Copy code
scanf("%d", &size);
getchar();  // Consume the newline character
For each test case, the program reads the size of matrices and consumes the newline character in the input buffer.

Declare and initialize arrays:

c
Copy code
int matrix[3][size][size];
int res[size][size];
matrix is a 3D array used to store three matrices.
res is a 2D array used to store the result of matrix multiplication.
Read matrix values:

c
Copy code
for (int j = 0; j < 3; j++) {
    for (int k = 0; k < size; k++) {
        for (int l = 0; l < size; l++) {
            scanf("%d", &matrix[j][k][l]);
            getchar();  // Consume the newline character
        }
    }
}
This code reads values for each of the three matrices (indexed by j) and consumes the newline characters in the input buffer after each value.

Perform matrix multiplication:

c
Copy code
// Matrix multiplication logic here
The program performs two matrix multiplications, first matrix[0] * matrix[1] and then matrix[0] * matrix[2], and stores the results in the res array.

Print the results:

c
Copy code
// Print the results and/or manipulate matrices
The program prints debugging information, including the intermediate steps of matrix multiplication. However, it doesn't display the final results or any specific output.

This code is missing the actual logic for matrix multiplication and doesn't show the final results. You would need to add the missing logic to complete the program. */
}
