#include<stdio.h>
int main(){
	int day, from, until, i, j;

	int friends;
	int view [101];
	scanf("%d", &day); getchar();
	for (i=1;i<=day;i++){
		scanf("%d", &view[i]); getchar();
	}
	scanf("%d", &friends);
	for (j=1;j<=friends;j++){
		int result=0;
		scanf("%d %d", &from, &until); getchar();
		for(i=from;i<=until;i++){
			result=result+view[i];
		}
	printf("Case #%d: %d\n", j, result);
	}

	return 0;
}
