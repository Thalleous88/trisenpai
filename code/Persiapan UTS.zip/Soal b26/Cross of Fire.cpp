//WOI INI JALAN TT
#include<stdio.h>

//lakukan pengurangan
void doSomething(int row, int column, int f, int m[12][12], int n){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(i==row && j==column){ //klo barisnya ya kurangi f*f
				m[i][j]=m[i][j]-f*f;
				if(m[i][j]<0){
					m[i][j]=0;
				}
			}else if(i==row || j==column){ //klo salah satunya aja kurangi f
				m[i][j]=m[i][j]-f;
				if(m[i][j]<0){
					m[i][j]=0;
				}
			}
		}
	}
}

int main(){
	int n, f, largest;
	int m[12][12];
	scanf("%d %d", &n, &f); //scan matriks
	
	largest=0; //set dulu
	//loop untuk input n cek largest
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			scanf("%d", &m[i][j]); //scan array
			if(m[i][j]>largest)largest=m[i][j]; //cari maksimum
		}
	}
	
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(m[i][j]==largest){ //kaya di lock gt loh
				doSomething(i, j, f, m, n); //ke void
			}
		}
	}
	//cetak
	printf("ans:");
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			printf(" %d", m[i][j]);
		}
	}
	printf("\n");
	
	
	return 0;
}
