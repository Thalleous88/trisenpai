#include <stdio.h>

int main(){
    int t, i, j, loop;
    int arr[26];
    char temp;
    int max;
    int maxNum;
    int validation, count;
    scanf("%d", &t); getchar();
    for(loop = 0; loop < t; loop++){
        for(i = 0; i < 26; i++){
            arr[i] = 0;
        }

        while(1){
            scanf("%c", &temp);
            if(temp == '\n'){
                break;
                }
            else{
                int pos = temp - 'a';
                arr[pos]++;
            }
        }

        printf("Case #%d: ", loop+1);
        max = 0;
        maxNum = 0;
        for(i = 0; i < 26; i++){
            if(arr[i] == 0){
                continue;
            }
            count = 0;
            for(j = i; j < 26; j++){
                if(arr[j] == arr[i]) count++;
            }
            if(count > max){
                max = count;
                maxNum = arr[i];
            }
        }

        validation = 0;
        for(i = 0; i < 26; i++){
            if(arr[i] == 0){
                continue;
            }
            else if(arr[i] != maxNum){
                validation++;
            }
        }
        if(validation > 1){
            printf("N/A");
        }
        else{
            for(i = 0; i < 26; i++){
                if(arr[i] == maxNum){
                    printf("%c", i + 'a');
                }
            }
        }
        printf("\n");
    }
}







/*#include<stdio.h>


char cekAgain(){
	
	
	return newS;
}


int main(){
	int t,x, j, k, l;
	char s[100005], newS[100005];
	char arr[30]={0}; // menampung alfabet
	char arr2[30]={0};
	
	scanf("%d", &t);
	
	for(int i=1;i<=t;i++){//loop case
		printf("Case #%d : ", i);
			
		scanf("%s", s); getchar(); //input kalimat
		int len=strlen(s);//hitung panjang string input
		
		for(j=0;j<len;j++){ //hitung jumlah 
			arr[s[j]]++; //arr[a]
		}

		int lenArr=sizeof(arr);		
		for(k=0;k<lenArr;k++){
			arr2[arr[j]]++; //arr[3] isinya yg jumlahnya sama dri array
		}
		
		int lenArr2=sizeof(arr2);
		if(lenArr2>2){
			printf("N/A\n");
		}else{
			for(k=0;k<lenArr;k++){
				printf("%c", )
			}
		}	
		
		/*
		int x=0; //di atur dulu ada huruf apa aja
		for(int j=0;j<len;j++){
			int count=0;
			for(int k=0;k>=j;k++){
				if(k==j)continue;
				else if(s[j]==s[k])count++;
			}
			if(count==0){
				newS[x]==s[j];
				x++;
			}
		}
		*/
	
	printf("%s")	
	}
	return 0;
}
