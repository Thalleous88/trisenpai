//WOI INI BISA JUGA TT
#include<stdio.h>
#include<math.h>

int main(){
	int ppl, smt; //p, s
	long long int price;
	float langkah1;
	scanf("%d %lld %d", &ppl, &price, &smt);
	while(smt--){
		langkah1=price*0.05/ppl;
		price=price+floor(langkah1);
	}
	printf("%lld\n", price);
	
	return 0;
}
