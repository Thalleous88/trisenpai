#include<stdio.h>

struct dat{
	char name;
	int jml={0};
}zat[30];


int cekbe4(int dt, char a){
	for(int i=0;i<dt;i++){
		if(a==zat[i].name){
			return i;
		}
	}
	return -1;
	
}

int main(){
	int t;
	char czat[100005];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%s", czat);
		
		int dt=0;
		int data=0;
		int len=strlen(czat);
		
		for(int j=0;j<len;j++){
			if(data==0){
				zat[dt].name=czat[j];
				zat[dt].jml++;
				dt++;
			}else{
				int l=cekbe4(dt, czat[j]);
				if(l!=-1){
					zat[l].jml++;
				}else{
					zat[dt].name=czat[j];
					zat[dt].jml++;
					dt++;
				}
			}
			data++;
		}	
		
		int counter=0;
		for(int j=0;j<dt-1;j++){
			if(zat[j].jml!=zat[j+1].jml){
				counter++;
			}
		}
		
		printf("Case %d: ", i);
		if(counter==0){
			for(int j=0;j<dt;j++){
				printf("%c", zat[j].name);
			}
		}else if()
	}
	

	
	return 0;
}
