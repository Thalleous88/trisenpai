//AAAAAAAAA INI JUGA JADI TT
#include<stdio.h>

void cekBos(int a[105], int b[105], int *bosA, int *bosB, int n){
	int count;
	for(int i=0;i<n;i++){
		count=0;
		for(int j=i+1;j<n;j++){
			if(a[i]<=a[j])count++;
		}
		if(count==0)(*bosA)++;
	}
	for(int i=0;i<n;i++){
		count=0;
		for(int j=i+1;j<n;j++){
			if(b[i]<=b[j])count++;
		}
		if(count==0)(*bosB)++;
	}
}


int main(){
	int n, a[105], b[105], bosA, bosB;
	scanf("%d", &n); 
	
	//input deret untuk a & b
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
	for(int i=0;i<n;i++){
		scanf("%d", &b[i]);
	}
	
	bosA=n;
	bosB=n;
	cekBos(a, b, &bosA, &bosB, n);
	
	if(bosA==bosB){
		printf("draw\n");
	}else if(bosA>bosB){
		printf("a\n");
	}else if(bosB>bosA){
		printf("b\n");
	}
	
	return 0;
}
