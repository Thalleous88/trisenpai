#include<stdio.h>
int hitung(int angka){
	int angka2;
	int a;
	while(angka>=10){
		angka2=angka;
		angka=0;
		while(angka2>0){
			a=angka2%10;
			angka=angka+a;
			angka2=angka2/10;
		}
	}
	return angka;
}
int main(){
	int n, a[100];
	scanf("%d", &n);
	int hasil=0;
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
		hasil=hasil+a[i];
	}
	printf("%d\n", hitung(hasil));
	return 0;
}

/*
#include<stdio.h>
int hitung(int angka){
	int angka2;
	int a;
	while(angka>=10){
		angka2=angka;
		angka=0;
		while(angka2>0){
			a=angka2%10;
			angka=angka+a;
			angka2=angka2/10;
		}
		if(angka<10)return angka;
	}
}
int main(){
	int n, a[100];
	scanf("%d", &n);
	int hasil=0;
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
		hasil=hasil+a[i];
	}
	if(hasil<10){
		printf("%d\n", hasil);
	}else{
		printf("%d\n", hitung(hasil));
	}
	return 0;
}
*/
