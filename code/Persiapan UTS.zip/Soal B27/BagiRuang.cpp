#include<stdio.h>
int main(){
	int x, m, n, t;
	double luas=0;
	scanf("%d", &x);
	while(x--){
		scanf("%d %d", &m, &n);
		luas=luas+n*m;
	}
	scanf("%d", &t);
	printf("%.2lf\n", luas/t);
	return 0;
}
