#include<stdio.h>

int main(){
	int m, n, a[100];
	scanf("%d %d", &m, &n);
	for(int i=0;i<m;i++){
		scanf("%d", &a[i]);
	}
	for(int i=0;i<m;i++){
		if(a[i]==-1){
			int hasil=0;
			int count=0;
			for(int j=i-n;j<=i+n && j<m;j++){
				if(a[j]!=-1){
					hasil=hasil+a[j];
					count++;
				}
			}
			a[i]=hasil/count;
			printf("%d", a[i]);
		}else{
			printf("%d", a[i]);
		}
		i==m-1?printf("\n"):printf(" ");
	}
	return 0;
}
