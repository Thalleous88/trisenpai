#include<stdio.h>
#include<string.h>
int main(){
	char m[105], s[105]; //kalimat, mantra
	scanf("%s", m); getchar();
	scanf("%s", s); getchar();
	for(int i=0;i<strlen(m);i++){
		for(int j=0;j<strlen(s);j++){
			if(m[i]!=s[j])printf("%c", m[i]);
		}	
	}printf("\n");
	
	return 0;
}
