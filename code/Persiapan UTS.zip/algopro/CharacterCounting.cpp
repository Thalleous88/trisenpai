#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main(){
	int huruf, n, count;
	char kalimat[1005];
	scanf("%[^\n]", kalimat); getchar(); //jangan lupa inputnya tuh sampe enter bukan space
	n=strlen(kalimat);
	
	//loop huruf
	for(huruf=97;huruf<=122;huruf++){ //97 itu a, 122 itu z
		count=0;
		for(int i=0;i<n;i++){
			if(tolower(kalimat[i])==huruf){ //set yg huruf besar ke kecil aja dulu
				count++;
			}
		}
		if(count>0){
		printf("%c -> %d\n", huruf, count);			
		}
	}
	return 0;
}
