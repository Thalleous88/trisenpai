//YEAY JADI

#include<stdio.h>
#include<string.h>
#include<ctype.h>

void checkPalindrome(char *newS, int m, int *result){
	int i, j;
	for(i=0, j=m-1;i<j;i++,j--){
		if(newS[i]==newS[j]){
			continue;
		}else{
			(*result)++; //pointer yg diubah jd nnti bisa di kirim balik
		}
	}
}

int main(){
	int t;
	char s[102];
	char newS[102];
	int result;
	//masukkan jumlah tasecasenya
	scanf("%d", &t); getchar(); //biat ga error
	for(int i=0;i<t;i++){
		int j, k;
		//masukkan kalimatnya
		scanf("%[^\n]", s); getchar(); //biar ga error
		int n=strlen(s);
		
		for(j=0, k=0;j<n;j++){
			if(!isspace(s[j])){ //ini bisa diganti pake == 'ascii space'
				newS[k]=tolower(s[j]); //masukin ke string baru, make sure its not space
				k++;
			}
		}
		int m=strlen(newS); //bisa diganti k
		
		result=0;
		checkPalindrome(newS, m, &result); //kirim alamatnya biar ga error
		
		if(result>0){
			printf("false\n");
		}
		else{
			printf("true\n");
		}
	}
	return 0;
}
