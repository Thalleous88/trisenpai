#include <stdio.h>
#include <string.h>

int main(){
    int tc,flag,afterDots,dots;
    char b[110];
    scanf("%d",&tc);getchar();
    for(int i=1;i<=tc;i++){
        flag=1;
        afterDots=1;
        dots=0;
        scanf("%[^\n]",&b);getchar();
        int len=strlen(b);
        for(int j=0;j<len;j++){
            if(b[j]=='.'){
                if(afterDots)flag=0;
                dots++;
                afterDots=1;
            }
            else afterDots=0;
        }
        printf("Case #%d: ",i);
        (dots==5 && flag)? printf("YES\n"): printf("NO\n");
    }
}



/*#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isPalindrome(char *str) {
    int left = 0;
    int right = strlen(str) - 1;

    while (left < right) {
        while (!isalnum(str[left]) && left < right) {
            left++;
        }
        while (!isalnum(str[right]) && left < right) {
            right--;
        }

        if (tolower(str[left]) != tolower(str[right])) {
            return 0;  // Not a palindrome
        }

        left++;
        right--;
    }

    return 1;  // It is a palindrome
}

int main() {
    char input[1000];
    printf("Enter a string: ");
    fgets(input, sizeof(input), stdin);

    // Remove spaces from the input
    char cleaned[1000];
    int i, j = 0;
    for (i = 0; input[i] != '\0'; i++) {
        if (!isspace(input[i])) {
            cleaned[j] = input[i];
            j++;
        }
    }
    cleaned[j] = '\0';

    if (isPalindrome(cleaned)) {
        printf("The input string is a palindrome.\n");
    } else {
        printf("The input string is not a palindrome.\n");
    }

    return 0;
}
*/
