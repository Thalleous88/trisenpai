//YAY BERHASIL
#include<stdio.h>
int main(){
	int x, y, a, b, c, d[100000], final;
	scanf("%d\n%d", &x, &y);
	for(int i=x, c=0 ; i<=y ; i++){
		if(6==i%7 && 4==i%5 && 2==i%3){
			d[c]=i;
			c++;
			final=i;
		}
	}
	printf("%d\n%d", d[0], final);//d[c-1]); //IDK KNP INI HASILNYA 0
	return 0;
}
