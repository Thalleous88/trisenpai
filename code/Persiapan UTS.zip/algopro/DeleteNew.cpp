/*#include<stdio.h>
	//input		: algoritma dan pemrograman binus university
	//output	: algoritm- dan pemrog-a--n binus univers-ty

int main(){
	char kalimat[100003];
	scanf("%[^\n]", kalimat);
	int len=strlen(kalimat);
	
	int i=0
	while(i<len){
		j=i;
		for(j=i;kalimat[j]!=' '||kalimat[j]!='\n';j++){
			i++;
		}
		
		for(k=j;k<=i;k++){
			for(l=k;l<=i;l++){
				
			}
		}
	}
	
	return 0;
}
*/



#include <stdio.h>
#include <string.h>

int main() {
    char kalimat[100005];
    int i, j, k, len;
    scanf("%[^\n]", kalimat); getchar();
    len = strlen(kalimat);
    
    i = 0;
    while (i<len){
        j = i;
        while(kalimat[j]!=' ' && kalimat[j]!='\0') {
            j++;
        }
        // Process each word
        for (k=i;k<j;k++) {
            int isDuplicate=0;
            for (int l=i;l<k;l++) {
                if (kalimat[k]==kalimat[l]) {
                    isDuplicate=1;
                    break;
                }
            }
            if(!isDuplicate) { //==0
                printf("%c", kalimat[k]);
            }
        }
        i = j + 1; // Move to the next word and skip the space
        if (i<len) {
            // Print space after the word
            printf(" ");
        }
    }
    printf("\n");
    return 0;
}

