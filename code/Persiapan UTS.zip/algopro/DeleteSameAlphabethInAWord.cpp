#include<stdio.h>

int main(){
	//input		: algoritma dan pemrograman binus university
	//output	: algoritm- dan pemrog-a--n binus univers-ty
	char kalimat[100005];
	int n, i, j, k, count;
	scanf("%[^\n]", kalimat);
//	n=strlen(kalimat);
	count=0;
	for(i=0;kalimat[i]!='\n';i++, j++){
		for(j=i;kalimat[j]!=' ';j++, i++){
			for(k=j;kalimat[j]!=' '; j++, i++){
				if(kalimat[j]==kalimat[i])count++;
				if(kalimat[j]==' ') break;
			}
			if(count>0)continue;
			else{
				printf("%c", kalimat[j]);
			}			
		}
		printf(" ");
		count=0;			
	}
	
	return 0;
}
