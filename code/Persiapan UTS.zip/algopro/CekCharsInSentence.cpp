#include<stdio.h>
#include<string.h>
int main(){
	char kalimat[10005], cek[10];
	int lenKal, lenCek, i, j, k, l, count, countt;
	
	//input kalimat dan kata yg mau dicari
	scanf("%[^\n]", kalimat); getchar();
	scanf("%s", cek); getchar();
	lenKal=strlen(kalimat);
	lenCek=strlen(cek);
	
	i=0;
	countt=0;
	for(j=i;j<=lenKal-lenCek;j++){ //ini yg berubah
		i=j; //saling update value
		count=0;
		for(k=0;k<lenCek;k++, j++){//k ttp 0
			if(kalimat[j]==cek[k]) count++; //klo sama itung, yg sama brp
		}
		j=i; //saling update value
		if(count==lenCek)countt++;//artinya klo semua kata yg dicek sama, ya itung
	}
	printf("%d\n", countt);
	return 0;
}
