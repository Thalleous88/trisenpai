#include<stdio.h>

int cekFPB(int smallest, int n, int a[105]){
	int count;
	for(int j=smallest;j>=1;j--){
		count=0;
		for(int k=0;k<n;k++){
			if(a[k]%j==0)count++;
		}
		if(count==n)return j;
	}
}

int main(){
	int t, n, a[105], smallest;
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%d", &n);
		smallest=10000;
		for(int j=0;j<n;j++){
			scanf("%d", &a[j]);
			if(a[j]<smallest)smallest=a[j];
		}
	printf("FPB #%d : %d\n", i, cekFPB(smallest, n, a));		
	}
	return 0;
}
