#include<stdio.h>
#include<string.h>
int main(){
	char kalimat[1005];
	int n;
	scanf("%[^\n]", kalimat);
	n=strlen(kalimat);
//	printf("%c", kalimat[0]);
	for(int i=0;i<n;i++){
		if(kalimat[i]!=kalimat[i-1]){//klo ga sama ky sebelumnya ya cetak
			printf("%c", kalimat[i]);
		}
	}
	printf("\n");
	return 0;
}
