//i think it works
#include<stdio.h>
#include<stdlib.h>

int main(){
	int t, n, a[12], result;
	scanf("%d", &t); //input testcase
	for(int i=1;i<=t;i++){
		scanf("%d", &n); //input jumlah bilangan
		for(int j=0;j<n;j++){
			scanf("%d", &a[j]); //masukkan a ke masing" array
		}
		result=INT_MAX;
		
		for(int j=0;j<n;j++){ //looping u/ cek per angka di array --ini yg jarang gerak
			for(int k=j;k<n;k++){ //looping u/ cek per angka di array --ini yg gerak mulu
				//klo posisi angkanya sama ya skip
				if(j==k) continue; 
				
				else if(a[j]>a[k] && result>a[j]-a[k]){
					result=a[j]-a[k];
				}
				
				else if(a[j]<a[k] && result>a[k]-a[j]){
					result=a[k]-a[j];
				}
				
				else if(a[j]==a[k] && result>a[k]-a[j]){//agak tdk mungkin sih
					result=a[k]-a[j];
				}
			}
		}
		printf(" %d\n", result);
	}
	return 0;
}
