//YEAY JADI

#include<stdio.h>
int main(){
	int t, k, p, key[102], pass[102], a, result;
	scanf("%d", &t);
	
	for(int i=1;i<=t;i++){
		scanf("%d %d", &k, &p);
		for(int j=0;j<k;j++){
			scanf("%d", &key[j]);
		}
		for(int j=0;j<p;j++){
			scanf("%d", &pass[j]);
		}
		
		for(int j=0;j<=k-p;j++){ //bkl looping sebanyak k-p
			result=0;
			for(int m=0, l=j; m<p; m++, l++){ //m mendefinisikan pass, l buat key
				a=key[l]^pass[m];
				result=result+a;
			}
			printf("%d", result);
			if(j==k-p) printf("\n");
			else {
				printf(" ");
			}
		}
	}
	return 0;
}
