#include<stdio.h>

int main(){
	//declare variables
	int tc, dat, jml;
	long long int harga, tot;
	char barang[150];
	
	//open file
	FILE *fdt=fopen("testdata.txt", "r");
	
	//read testcase
	fscanf(fdt, "%d\n", &tc);
	
	for(int i=1;i<=tc;i++){
		
		//read dat each tc
		fscanf(fdt, "%d\n", &dat);
		tot=0; //initialize total, start from 0
		
		for(int j=0;j<dat;j++){
			
			//read each line of tc
			fscanf(fdt, "%d#%[^@]@%lld\n", &jml, barang, &harga);
			//printf("JML : %d\n", jml);
			//printf("BRG : %s\n", barang);
			//printf("HRG : %lld\n", harga);
			
			//add total each line
			tot=tot+jml*harga;
			//printf("TOT : %lld\n", tot);
		}
		//count result after discount
		long long int result = tot*0.85;
		
		//print final result
		printf("Customer #%d: Rp %lld\n", i, result);
	}
	fclose(fdt);
	return 0;
}
