#include<stdio.h>

int checkAns(int a[30005], int n){
	for(int i=0;i<n-2;i++){
		if(a[i]>a[i-1]+a[i-2]){
			return 1;
		}	
	}
	return 0;	
}

int main(){
	int a[30005], n;
	scanf("%d", &n);
	for(int i=0;i<n;i++){
		scanf("%d", &a[i]);
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n-i-1;j++){
			if(a[j]<a[j+1]){
				int temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	
	for(int i=0;i<n;i++){
		printf("%d  ", a[i]);
	}
	
	if(checkAns(a, n)){
		printf("YES\n");
	}else{
		printf("NO\n");
	}
	
	return 0;
}
