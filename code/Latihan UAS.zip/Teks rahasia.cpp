#include<stdio.h>

int main(){
	int hh1, mm1, j, k;
	char str1[15][10010];
	char str2[15][10010];
	//include testcase
	//input kalimat 1
	scanf("%d:%d>", &hh1, &mm1);getchar();
	j=-1, k=-1;
	do{
		j++;
		do{
			k++;
			scanf("%c", &str1[j][k]);
		}while(str1[j][k]!=' ' && str1[j][k]!='\n');getchar();
		
	}while(str1[j][k]!='\n');
	//input kalimat 2
	j=-1, k=-1;
	do{
		j++;
		do{
			k++;
			scanf("%c", &str2[j][k]);
		}while(str1[j][k]!=' ' && str1[j][k]!='\n');getchar();
	}while(str1[j][k]!='\n');
	return 0;
}
