#include<stdio.h>
#include<ctype.h>

int visited[102][102];

struct dat{
	char name;
	int area;
}kd[30], temp;

void check(char map[150][510], int i, int j, int countkd){
	visited[i][j]=1;
	kd[countkd].area++;
	
	if(map[i-1][j]=='.' && visited[i-1][j]==0){
		check(map, i-1, j, countkd);
	}
	if(map[i+1][j]=='.' && visited[i+1][j]==0){
		check(map, i+1, j, countkd);
	}
	if(map[i][j+1]=='.' && visited[i][j+1]==0){
		check(map, i, j+1, countkd);
	}
	if(map[i][j-1]=='.' && visited[i][j-1]==0){
		check(map, i, j-1, countkd);
	}
}


int main(){
	int n, m;
	char map[150][510];
	
	scanf("%d %d", &n, &m);
	
	for(int i=0;i<n;i++){//baris
		for(int j=0;j<n;j++){//kolom
			scanf(" %c", &map[i][j]); //input gambar
		}
		getchar();
	}
	
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			visited[i][j]=0;
		}
	}
	
	int countkd=0;
	for(int i=0;i<n;i++){//baris
		for(int j=0;j<n;j++){//kolom
			if(isalpha(map[i][j])){
				kd[countkd].name=map[i][j];
				kd[countkd].area=0;
				check(map, i, j, countkd);
				countkd++;
			}
		}
	}
	
	for(int i=0;i<m;i++){
		for(int j=0;j<m-i-1;j++){
			if(kd[j].name>kd[j+1].name){
				temp=kd[j];
				kd[j]=kd[j+1];
				kd[j+1]=temp;
			}
		}
	}
	
	
	for(int i=0;i<m;i++){
		printf("%c %d\n", kd[i].name, kd[i].area);
	}
	return 0;
}





/*
#include<stdio.h>
#include<ctype.h>

int visited[102][102];

void check(char map[150][510], int i, int j, int *counter){
	visited[i][j]=1;
	*(counter)++;
	printf("dfgh : %d\n", *counter);
	
	if(map[i-1][j]=='.' && visited[i-1][j]==0){
		check(map, i-1, j, counter);
	}
	if(map[i+1][j]=='.' && visited[i+1][j]==0){
		check(map, i+1, j, counter);
	}
	if(map[i][j+1]=='.' && visited[i][j+1]==0){
		check(map, i, j+1, counter);
	}
	if(map[i][j-1]=='.' && visited[i][j-1]==0){
		check(map, i, j-1, counter);
	}

}


int main(){
	int n, m;
	char map[150][510];
	
	scanf("%d %d", &n, &m);
	
	for(int i=0;i<n;i++){//baris
		for(int j=0;j<n;j++){//kolom
			scanf(" %c", &map[i][j]);
		}
		getchar();
	}
	
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			visited[i][j]=0;
		}
	}
	
	for(int i=0;i<n;i++){//baris
		for(int j=0;j<n;j++){//kolom
			int counter=0;
			if(isalpha(map[i][j])){
				counter++;
				check(map, i, j, &counter);
				printf("%c %d\n", map[i][j], counter);
			}
		}
	}
	
	
	return 0;
}
*/
