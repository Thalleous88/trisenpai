#include<stdio.h>
#include<string.h>

struct dta{
	char name[100];
	long long int jumlah;
}text[150], temp;

int checkbe4(int j, char nme[150]){
	for(int k=0;k<j;k++){
		if(strcmp(nme, text[k].name)==0){
			return k;
		}
	}
	return -1;
}

int main(){
	char txt[150];
	char nme[150];
	
	//open file
	FILE *fo=fopen("teks_data.txt", "r");
	int dt=0; //jumlah data berbeda
	int data=0; //jumlah data yg ada
	
	//buat semua jumlah start from 0, gada jg gpp
	for(int k=0;k<151;k++){
		text[k].jumlah=0;
	}
	
	//selama bkn akhir filenya
	while(!feof(fo)){
		//baca datanya
		fscanf(fo, "%[^:]:%[^\n]\n", nme, txt);
		
		//kalo data pertama
		if(data==0){
			//simpen namanya
			strcpy(text[dt].name, nme);
			//tambah jumlahnya kata
			text[dt].jumlah+=strlen(txt);
			//data beda nambah
			dt++;
		}
		
		//klo bkn yg pertama
		else if(data!=0){
			//cek, sebelumnya ada ga nama dia
			int idx=checkbe4(dt, nme); 
			//klo ga ada
			if(idx==-1){
				//masukin data yg baru
				//masukin nama
				strcpy(text[dt].name, nme);
				//tambah jumlah kata
				text[dt].jumlah+=strlen(txt);
				dt++; //tambah jumlah datanya
			}
			//klo udh ada
			else{
				//cukup tambah jumlah kata sesuai index yg ketemu
				text[idx].jumlah+=strlen(txt);
			}
		}
		data++; //jumlah data yg dibaca nambah	
	}
	//tutup data
	fclose(fo);
	
	//sorting
	for(int k=0;k<dt;k++){
		for(int l=0;l<dt-k-1;l++){
			int x=0;
			//klo misal huruf dinamanya sama tambah lg buat bandingin
			while(text[l].name[x]==text[l+1].name[x]){
				x++;
			}
			//klo udh beda, cek lg lbh besar ga yg duluan
			if(text[l].name[x]>text[l+1].name[x]){
				temp=text[l];
				text[l]=text[l+1];
				text[l+1]=temp;
			}
		}
	}
	
	for(int k=0;k<dt;k++){
		//print data
		printf("%s - %lld\n", text[k].name, text[k].jumlah);
	}
	
	return 0;
}
