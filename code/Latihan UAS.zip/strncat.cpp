#include <stdio.h>
#include <string.h>

int main() {
    char destinasi[20] = "Halo, ";
    const char *sumber = "dunia!";
    size_t maks_karakter = 2;

    strncat(destinasi, sumber, maks_karakter);

    printf("String yang digabungkan: %s\n", destinasi);

    return 0;
}
